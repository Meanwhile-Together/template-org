/**
 * @fileoverview Engine package - Platform-agnostic cross-platform development.
 * Exports features, bridge, browser services, standalone engine, AI inferer, and app entry factory.
 */

// Core engine framework exports
export * from './src/features/index';
export * from './src/bridge/index';
export * from './src/browser/index';
// Explicit export for BridgeFactory to help bundlers resolve it
// Re-export from bridge/index which already exports from factory
import { BridgeFactory } from './src/bridge/factory';
export { BridgeFactory };
export type { BridgeFactoryConfig } from './src/bridge/factory';

// Standalone exports for environments without platform bridges
export * from './src/standalone';

// Main engine framework class
export { EngineFramework } from './src/engine';
export * from './src/ai/index';

// App entry factory
export * from './src/app/index';
