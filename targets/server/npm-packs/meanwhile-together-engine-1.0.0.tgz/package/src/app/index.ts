/**
 * @fileoverview App module - createAppEntry and Layout (view-based app shell with auth, theme, sidebar).
 */
export { createAppEntry } from './createAppEntry';
export { Layout } from './Layout';
export type { AppEntryProps, AppView, CreateAppEntryConfig } from './createAppEntry';
export type { LayoutProps, LayoutSlots, LayoutViewComponentProps, SidebarNavProps } from './Layout';