/**
 * @fileoverview App entry factory - createAppEntry builds the root App component (RootApp > ViewBasedApp > FallbackApp > div).
 */
import React from 'react';
import type { BridgeImpl, NavigationPlacement, ViewDefinition } from '@meanwhile-together/shared';

/**
 * Props passed to the app entry (and RootApp/ViewBasedApp/FallbackApp).
 * @typedef {Object} AppEntryProps
 * @property {BridgeImpl} [bridge] - Platform bridge.
 * @property {'light'|'dark'|'system'} [theme] - Theme mode.
 * @property {NavigationPlacement} [navigationPlacement] - Where nav appears.
 * @property {'left'|'right'} [sidebarSide] - Sidebar side.
 * @property {boolean} [sidebarPush] - Whether content pushes when sidebar open.
 */
export interface AppEntryProps {
  bridge?: BridgeImpl;
  theme?: 'light' | 'dark' | 'system';
  navigationPlacement?: NavigationPlacement;
  sidebarSide?: 'left' | 'right';
  sidebarPush?: boolean;
}

/**
 * Legacy view shape; use ViewDefinition from shared instead.
 * @deprecated Use ViewDefinition from @meanwhile-together/shared
 */
export interface AppView {
  id: string;
  name: string;
  component: React.ComponentType<any>;
  path?: string;
  icon?: string;
}

/**
 * Config for createAppEntry: RootApp, ViewBasedApp, FallbackApp, getViews.
 * @typedef {Object} CreateAppEntryConfig
 */
export interface CreateAppEntryConfig {
  /**
   * User's custom root App component (takes full control if provided)
   */
  RootApp?: React.ComponentType<AppEntryProps>;
  
  /**
   * Framework's view-based App component (used when views exist but no RootApp)
   */
  ViewBasedApp?: React.ComponentType<AppEntryProps>;
  
  /**
   * Fallback component when no app or views exist (typically FrameworkSplash from ui)
   */
  FallbackApp?: React.ComponentType<AppEntryProps>;
  
  /**
   * Function to get registered views (ViewDefinition from shared)
   */
  getViews?: () => ViewDefinition[];
}

/**
 * Create the application entry component. Priority: RootApp > ViewBasedApp (if views) > FallbackApp > empty div.
 * @param {CreateAppEntryConfig} config - RootApp, ViewBasedApp, FallbackApp, getViews.
 * @returns {React.FC<AppEntryProps>} App entry component.
 */
export function createAppEntry(config: CreateAppEntryConfig): React.FC<AppEntryProps> {
  const { RootApp, ViewBasedApp, FallbackApp, getViews } = config;

  const AppEntry: React.FC<AppEntryProps> = (props) => {
    // 1. User's custom root app takes priority
    if (RootApp) {
      return <RootApp {...props} />;
    }

    // 2. View-based app when views are registered
    if (ViewBasedApp && getViews) {
      const views = getViews();
      if (views.length > 0) {
        return <ViewBasedApp {...props} />;
      }
    }

    // 3. Fallback component (FrameworkSplash passed from application layer)
    if (FallbackApp) {
      return <FallbackApp {...props} />;
    }

    // 4. Absolute fallback
    return <div>No application configured</div>;
  };

  AppEntry.displayName = 'AppEntry';
  return AppEntry;
}
