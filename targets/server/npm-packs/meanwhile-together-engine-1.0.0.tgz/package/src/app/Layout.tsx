/**
 * @fileoverview Layout - View-based app layout with header, sidebar, auth, theme. Uses optional layout slots from ui (engine does not depend on ui).
 */
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import type { BridgeImpl } from '@meanwhile-together/shared';
import type { NavigationPlacement } from '@meanwhile-together/shared';
import type { ViewDefinition } from '@meanwhile-together/shared';
import { warnViewDefinitionConflicts } from '@meanwhile-together/shared';
import { useViewRouter } from '@meanwhile-together/shared';
import { useAuth, useAppConfig } from '@meanwhile-together/shared';
import { ThemeMode, ResolvedTheme, getResolvedTheme, getNextTheme, getThemeIcon } from '@meanwhile-together/shared';

const HEADER_HEIGHT = 60;
const SIDEBAR_WIDTH = 280;

/**
 * Nav data for sidebar content (optional SidebarContent slot).
 * @typedef {Object} SidebarNavProps
 * @property {ViewDefinition[]} navItems
 * @property {string} activeViewId
 * @property {(viewId: string) => void} onViewChange
 */
export interface SidebarNavProps {
  navItems: ViewDefinition[];
  activeViewId: string;
  onViewChange: (viewId: string) => void;
}

/**
 * Injectable layout components (Header, Sidebar, SidebarContent?, Auth, getSidebarPushStyle). Engine does not depend on ui.
 * @typedef {Object} LayoutSlots
 */
export interface LayoutSlots {
  Header: React.ComponentType<Record<string, unknown>>;
  Sidebar: React.ComponentType<Record<string, unknown> & { children?: React.ReactNode }>;
  SidebarContent?: React.ComponentType<SidebarNavProps>;
  Auth: React.ComponentType<Record<string, unknown>>;
  getSidebarPushStyle: (side: 'left' | 'right', open: boolean, width: number) => React.CSSProperties;
}

function defaultGetSidebarPushStyle(side: 'left' | 'right', open: boolean, width: number): React.CSSProperties {
  const w = `${width}px`;
  return side === 'left' ? { marginLeft: open ? w : 0 } : { marginRight: open ? w : 0 };
}

const DefaultHeader: React.ComponentType<Record<string, unknown>> = (props) => {
  const { appName } = props as { appName?: string };
  return (
    <header style={{ height: HEADER_HEIGHT, display: 'flex', alignItems: 'center', padding: '0 1rem', borderBottom: '1px solid #eee' }}>
      <span>{appName ?? 'App'}</span>
    </header>
  );
};

/** Default sidebar: container only; content comes from children (engine passes default or SidebarContent slot). */
const DefaultSidebar: React.ComponentType<Record<string, unknown> & { children?: React.ReactNode }> = (props) => (
  <aside style={{ width: SIDEBAR_WIDTH, borderRight: '1px solid #eee', padding: '1rem 0' }}>
    {props.children}
  </aside>
);

const navButtonStyle = (isActive: boolean): React.CSSProperties => ({
  display: 'flex',
  alignItems: 'center',
  gap: '0.75rem',
  padding: '0.75rem 1rem',
  width: '100%',
  textAlign: 'left',
  border: 'none',
  borderLeft: `3px solid ${isActive ? 'var(--accent-primary)' : 'transparent'}`,
  borderRadius: '0.375rem',
  background: isActive ? 'var(--bg-active)' : 'transparent',
  color: isActive ? 'var(--accent-primary)' : 'var(--text-secondary)',
  fontSize: '0.875rem',
  fontWeight: 500,
  cursor: 'pointer',
  transition: 'color, background, border-color 0.15s ease',
});

/** Default nav when no SidebarContent slot: top-level views with expandable sections for any view that has children (parentId). Uses theme CSS vars. */
const DefaultSidebarNav: React.FC<SidebarNavProps> = ({ navItems, activeViewId, onViewChange }) => {
  const [openSectionIds, setOpenSectionIds] = React.useState<Set<string>>(new Set());
  const topLevel = (navItems ?? []).filter(
    (v) => (v as ViewDefinition & { parentId?: string }).parentId == null && v.showInNav !== false
  );
  const getChildren = (parentId: string) =>
    (navItems ?? []).filter(
      (v) => (v as ViewDefinition & { parentId?: string }).parentId === parentId && v.showInNav !== false
    );
  const toggleSection = (id: string) => {
    setOpenSectionIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <nav aria-label="Main navigation" style={{ padding: '1rem 0' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingLeft: '0.75rem' }}>
        {topLevel.map((item) => {
          const isActive = activeViewId === item.id;
          const children = getChildren(item.id);
          const hasChildren = children.length > 0;
          const childActive = children.some((c) => c.id === activeViewId);
          const expanded = openSectionIds.has(item.id) || isActive || childActive;

          if (hasChildren) {
            return (
              <div key={item.id} style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                <button
                  type="button"
                  style={navButtonStyle(isActive || childActive)}
                  onMouseEnter={(e) => {
                    if (!isActive && !childActive) {
                      e.currentTarget.style.background = 'var(--bg-hover)';
                      e.currentTarget.style.color = 'var(--text-primary)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive && !childActive) {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.color = 'var(--text-secondary)';
                    }
                  }}
                  onClick={() => {
                    onViewChange(item.id);
                    toggleSection(item.id);
                  }}
                >
                  {item.icon != null && <span style={{ fontSize: '1.125rem' }}>{item.icon}</span>}
                  <span style={{ flex: 1 }}>{item.label}</span>
                  <span style={{ fontSize: '0.75rem', opacity: 0.7 }}>{expanded ? '▼' : '▶'}</span>
                </button>
                {expanded && (
                  <div style={{ paddingLeft: '1rem', marginLeft: '0.5rem', borderLeft: '1px solid var(--border-primary)' }}>
                    {children.map((child) => {
                      const childActiveItem = activeViewId === child.id;
                      return (
                        <button
                          key={child.id}
                          type="button"
                          style={{ ...navButtonStyle(childActiveItem), padding: '0.5rem 0.75rem' }}
                          onMouseEnter={(e) => {
                            if (!childActiveItem) {
                              e.currentTarget.style.background = 'var(--bg-hover)';
                              e.currentTarget.style.color = 'var(--text-primary)';
                            }
                          }}
                          onMouseLeave={(e) => {
                            if (!childActiveItem) {
                              e.currentTarget.style.background = 'transparent';
                              e.currentTarget.style.color = 'var(--text-secondary)';
                            }
                          }}
                          onClick={() => onViewChange(child.id)}
                        >
                          {child.icon != null && <span style={{ fontSize: '1rem' }}>{child.icon}</span>}
                          <span>{child.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }
          return (
            <button
              key={item.id}
              type="button"
              style={navButtonStyle(isActive)}
              onMouseEnter={(e) => {
                if (!isActive) {
                  e.currentTarget.style.background = 'var(--bg-hover)';
                  e.currentTarget.style.color = 'var(--text-primary)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'var(--text-secondary)';
                }
              }}
              onClick={() => onViewChange(item.id)}
            >
              {item.icon != null && <span style={{ fontSize: '1.125rem' }}>{item.icon}</span>}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

const DefaultAuth: React.ComponentType<Record<string, unknown>> = (props) => {
  const { login, register, error, onBack } = props as {
    login?: (email: string, password: string) => Promise<void>;
    register?: (email: string, password: string, name: string) => Promise<void>;
    error?: string | null;
    onBack?: () => void;
  };
  return (
    <div style={{ padding: '2rem', maxWidth: 400 }}>
      {onBack && (
        <button type="button" onClick={onBack}>
          Back
        </button>
      )}
      {error != null && error !== '' && <p style={{ color: 'red' }}>{String(error)}</p>}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const form = e.target as HTMLFormElement;
          const email = (form.querySelector('[name=email]') as HTMLInputElement)?.value ?? '';
          const password = (form.querySelector('[name=password]') as HTMLInputElement)?.value ?? '';
          const name = (form.querySelector('[name=name]') as HTMLInputElement)?.value ?? '';
          if (login) void login(email, password);
          else if (register) void register(email, password, name);
        }}
      >
        <input name="email" type="email" placeholder="Email" required />
        <input name="password" type="password" placeholder="Password" required />
        <input name="name" type="text" placeholder="Name (register)" />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

/**
 * Props for the Layout component.
 * @typedef {Object} LayoutProps
 * @property {() => ViewDefinition[]} getViews - Source of view definitions.
 * @property {(id: string) => React.ComponentType|undefined} getViewComponent - Resolve view component by id.
 * @property {() => ViewDefinition[]} [useViews] - Reactive view list (overrides getViews when provided).
 * @property {() => (id: string) => React.ComponentType|undefined} [useGetViewComponent] - Reactive getViewComponent.
 * @property {BridgeImpl} [bridge]
 * @property {ThemeMode} [theme]
 * @property {NavigationPlacement} [navigationPlacement]
 * @property {'left'|'right'} [sidebarSide]
 * @property {boolean} [sidebarPush]
 * @property {string} [initialViewId]
 * @property {React.ReactNode} [footer]
 * @property {boolean} [requireAuth]
 * @property {LayoutSlots} [layoutSlots]
 */
/** Props passed to each resolved view component from {@link Layout}. */
export type LayoutViewComponentProps = {
  theme?: 'light' | 'dark';
  bridge?: unknown;
  /** Navigate to another top-level view id (from engine shell). */
  onNavigateView?: (viewId: string) => void;
  onLogin?: () => void;
  onRegister?: () => void;
};

export interface LayoutProps {
  getViews: () => ViewDefinition[];
  getViewComponent: (id: string) => React.ComponentType<LayoutViewComponentProps> | undefined;
  useViews?: () => ViewDefinition[];
  useGetViewComponent?: () => (id: string) => React.ComponentType<LayoutViewComponentProps> | undefined;
  bridge?: BridgeImpl;
  theme?: ThemeMode;
  /**
   * Where nav appears: `left` / `right` / `*-tabs` / `*-dropdown` = header; `*-sidebar` / `*-sidebar-push` = sidebar (+ hamburger on small screens).
   */
  navigationPlacement?: NavigationPlacement;
  sidebarSide?: 'left' | 'right';
  sidebarPush?: boolean;
  initialViewId?: string;
  footer?: React.ReactNode;
  requireAuth?: boolean;
  /**
   * Show Login in the header when logged out. If omitted, matches `requireAuth` (show when sign-in is required).
   */
  showHeaderLogin?: boolean;
  /**
   * Show Register in the header when logged out. If omitted, matches `requireAuth`.
   */
  showHeaderRegister?: boolean;
  layoutSlots?: LayoutSlots;
}

/**
 * View-based layout: header, optional sidebar, auth gate, theme, view router. Uses layoutSlots when provided.
 */
export const Layout: React.FC<LayoutProps> = ({
  getViews,
  getViewComponent,
  useViews: useViewsProp,
  useGetViewComponent: useGetViewComponentProp,
  bridge,
  theme: initialTheme = 'system',
  navigationPlacement = 'left-sidebar-push',
  sidebarSide = 'left',
  sidebarPush = true,
  initialViewId,
  footer,
  requireAuth = true,
  showHeaderLogin: showHeaderLoginProp,
  showHeaderRegister: showHeaderRegisterProp,
  layoutSlots,
}) => {
  const { user, logout, isAuthenticated, login, register: registerFn, error: authError } = useAuth();
  const { appName } = useAppConfig();
  const [themeMode, setThemeMode] = useState<ThemeMode>(initialTheme);
  const [resolvedTheme, setResolvedTheme] = useState<ResolvedTheme>(getResolvedTheme(initialTheme));
  const viewsFromHook = useViewsProp?.();
  const views = viewsFromHook ?? useMemo(() => getViews(), [getViews]);
  const getViewComponentFn = useGetViewComponentProp?.() ?? getViewComponent;

  const homeView = views.find((v) => v.id === 'home');
  const defaultViewId = initialViewId ?? homeView?.id ?? views[0]?.id ?? 'home';

  const { activeViewId, navigateToView } = useViewRouter(views, defaultViewId);

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  const showHeaderLogin = showHeaderLoginProp ?? requireAuth;
  const showHeaderRegister = showHeaderRegisterProp ?? requireAuth;

  useEffect(() => {
    warnViewDefinitionConflicts(views);
  }, [views]);

  const defaultViewIdWhenAuthenticated = useMemo(() => {
    const first = views.find((v) => !v.hideWhenAuthenticated);
    return first?.id ?? homeView?.id ?? defaultViewId;
  }, [views, defaultViewId, homeView?.id]);

  const getRedirectTargetOffGuestOnlyView = useCallback(
    (guestOnlyView: ViewDefinition): string => {
      const val = guestOnlyView.hideWhenAuthenticated;
      if (val === true) return homeView?.id ?? defaultViewIdWhenAuthenticated;
      if (typeof val === 'string') {
        const target = views.find((v) => v.id === val);
        if (target && !target.hideWhenAuthenticated) return val;
      }
      return defaultViewIdWhenAuthenticated;
    },
    [views, defaultViewIdWhenAuthenticated, homeView?.id]
  );

  const availableViews = useMemo(() => {
    if (!requireAuth && !isAuthenticated) {
      return views.filter((v) => !v.needAuthorization);
    }
    if (isAuthenticated) {
      return views.filter((v) => !v.hideWhenAuthenticated);
    }
    return views;
  }, [views, requireAuth, isAuthenticated]);

  useEffect(() => {
    if (!requireAuth && !isAuthenticated) {
      const activeView = views.find((v) => v.id === activeViewId);
      if (activeView?.needAuthorization === true) {
        navigateToView(homeView?.id ?? views[0]?.id ?? 'home');
      }
    }
  }, [requireAuth, isAuthenticated, activeViewId, views, navigateToView, homeView?.id]);

  useEffect(() => {
    if (requireAuth || !isAuthenticated) return;
    const activeView = views.find((v) => v.id === activeViewId);
    if (activeView?.hideWhenAuthenticated) {
      navigateToView(getRedirectTargetOffGuestOnlyView(activeView));
    }
  }, [requireAuth, isAuthenticated, activeViewId, views, navigateToView, getRedirectTargetOffGuestOnlyView]);

  useEffect(() => {
    const updateResolvedTheme = () => {
      setResolvedTheme(getResolvedTheme(themeMode));
    };
    updateResolvedTheme();
    if (themeMode === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      mediaQuery.addEventListener('change', updateResolvedTheme);
      return () => mediaQuery.removeEventListener('change', updateResolvedTheme);
    }
    return () => {};
  }, [themeMode]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', resolvedTheme);
    return () => document.documentElement.removeAttribute('data-theme');
  }, [resolvedTheme]);

  const handleViewChange = (viewId: string): void => {
    const targetView = views.find((v) => v.id === viewId);
    if (!requireAuth && !isAuthenticated) {
      if (targetView?.needAuthorization === true) {
        navigateToView(homeView?.id ?? views[0]?.id ?? 'home');
        return;
      }
    }
    if (isAuthenticated && targetView?.hideWhenAuthenticated) {
      navigateToView(getRedirectTargetOffGuestOnlyView(targetView));
      return;
    }
    navigateToView(viewId);
  };
  const toggleSidebar = () => setSidebarOpen((o) => !o);
  const toggleTheme = () => setThemeMode(getNextTheme(themeMode));
  const handleLogin = () => {
    setAuthMode('login');
    setShowAuth(true);
  };
  const handleRegister = () => {
    setAuthMode('register');
    setShowAuth(true);
  };

  useEffect(() => {
    if (isAuthenticated && showAuth) {
      setShowAuth(false);
    }
  }, [isAuthenticated, showAuth]);

  const HeaderComp = layoutSlots?.Header ?? DefaultHeader;
  const SidebarComp = layoutSlots?.Sidebar ?? DefaultSidebar;
  const SidebarContentComp = layoutSlots?.SidebarContent ?? DefaultSidebarNav;
  const AuthComp = layoutSlots?.Auth ?? DefaultAuth;
  const getPushStyle = layoutSlots?.getSidebarPushStyle ?? defaultGetSidebarPushStyle;

  const isSidebarNav = navigationPlacement.includes('sidebar');
  const pushStyle = isSidebarNav && sidebarPush
    ? getPushStyle(sidebarSide, sidebarOpen, SIDEBAR_WIDTH)
    : { marginLeft: 0, marginRight: 0 };

  const ActiveView = getViewComponentFn(activeViewId);

  if (showAuth && !isAuthenticated) {
    return (
      <div className="flex flex-col h-screen overflow-hidden bg-bg-primary text-text-primary" data-theme-mode={themeMode}>
        <AuthComp
          theme={resolvedTheme}
          initialMode={authMode}
          login={async (email: string, password: string) => { await login(email, password); }}
          register={async (email: string, password: string, name: string) => { await registerFn(email, password, name); }}
          error={authError}
          loading={false}
          onBack={() => setShowAuth(false)}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-bg-primary text-text-primary" data-theme-mode={themeMode}>
      <HeaderComp
        appName={appName}
        appIcon="🐕"
        navItems={availableViews}
        activeNavId={activeViewId}
        onNavChange={handleViewChange}
        navigationPlacement={navigationPlacement}
        user={user ? { name: user.name ?? undefined, email: user.email } : undefined}
        theme={resolvedTheme}
        onLogout={logout}
        onLogin={!isAuthenticated && showHeaderLogin ? handleLogin : undefined}
        onRegister={!isAuthenticated && showHeaderRegister ? handleRegister : undefined}
        onThemeToggle={toggleTheme}
        themeIcon={getThemeIcon(themeMode)}
        showSidebarToggle={isSidebarNav}
        onSidebarToggle={toggleSidebar}
        height={HEADER_HEIGHT}
      />

      <div className="flex flex-1 overflow-hidden" style={{ marginTop: HEADER_HEIGHT }}>
        {isSidebarNav && (
          <SidebarComp
            side={sidebarSide}
            push={sidebarPush}
            open={sidebarOpen}
            onClose={toggleSidebar}
            width={SIDEBAR_WIDTH}
            top={HEADER_HEIGHT}
            className="border-r border-border-primary"
            overlayClassName="md:hidden"
          >
            <SidebarContentComp
              navItems={availableViews}
              activeViewId={activeViewId}
              onViewChange={handleViewChange}
            />
          </SidebarComp>
        )}

        <main
          className="flex-1 overflow-auto transition-all"
          style={pushStyle}
        >
          {ActiveView ? (
            <ActiveView
              theme={resolvedTheme}
              bridge={bridge}
              onNavigateView={handleViewChange}
              {...(!isAuthenticated
                ? {
                    ...(showHeaderLogin ? { onLogin: handleLogin } : {}),
                    ...(showHeaderRegister ? { onRegister: handleRegister } : {}),
                  }
                : {})}
            />
          ) : (
            <div className="p-10 text-center text-text-secondary">View not found</div>
          )}
        </main>
      </div>

      {footer && (
        <footer className="bg-bg-secondary border-t border-border-primary py-4 px-6">
          {footer}
        </footer>
      )}
    </div>
  );
};
