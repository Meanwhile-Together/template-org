/**
 * @fileoverview Engine Framework - Main orchestrator for platform-agnostic adaptive functionality.
 * Provides feature detection, platform capabilities, and AI/text generation via an optional platform bridge.
 */

import type { BridgeImpl, DetectedFeature, PlatformCapabilities } from '@meanwhile-together/shared';
import { FeatureDetectionService } from '@meanwhile-together/engine';

/**
 * Configuration for the EngineFramework instance.
 * @typedef {Object} EngineFrameworkConfig
 * @property {'web'|'desktop'|'mobile'|'node'} [platform] - Target platform (default: 'web').
 * @property {BridgeImpl} [platformBridge] - Optional platform bridge for native/cloud APIs.
 * @property {boolean} [enableLogging] - Enable console logging.
 * @property {boolean} [enableFeatureDetection] - Enable feature detection (default: true when bridge present).
 */
export interface EngineFrameworkConfig {
  platform?: 'web' | 'desktop' | 'mobile' | 'node';
  platformBridge?: BridgeImpl;
  enableLogging?: boolean;
  enableFeatureDetection?: boolean;
}

/**
 * Current framework state (platform, features, capabilities, online status).
 * @typedef {Object} EngineFrameworkState
 * @property {string} platform - Current platform identifier.
 * @property {DetectedFeature[]} features - All detected features.
 * @property {PlatformCapabilities} capabilities - Platform capability flags.
 * @property {boolean} online - Whether the platform reports online.
 */
export interface EngineFrameworkState {
  platform: string;
  features: DetectedFeature[];
  capabilities: PlatformCapabilities;
  online: boolean;
}

/**
 * Main engine framework: orchestrates feature detection, capabilities, and optional AI via platform bridge.
 */
export class EngineFramework {
  private platformBridge?: BridgeImpl;
  private platform: string;
  private featureDetection: FeatureDetectionService;
  private logger: Console | null;
  private state: EngineFrameworkState;

  /**
   * Create an EngineFramework instance.
   * @param {EngineFrameworkConfig} [config={}] - Framework configuration.
   */
  constructor(config: EngineFrameworkConfig = {}) {
    this.platformBridge = config.platformBridge;
    this.platform = config.platform || 'web';
    this.logger = config.enableLogging ? console : null;

    // Initialize feature detection
    this.featureDetection = new FeatureDetectionService(
      this.platformBridge,
      this.platform,
      { enableLogging: config.enableLogging }
    );

    // Initialize state
    this.state = {
      platform: this.platform,
      features: [],
      capabilities: this.featureDetection.capabilities(),
      online: true
    };

    this.log('EngineFramework initialized', { platform: this.platform });
  }

  /**
   * Initialize the framework and detect all capabilities.
   * @returns {Promise<void>}
   */
  async initialize(): Promise<void> {
    this.log('Initializing EngineFramework...');

    // Detect features
    this.state.features = this.featureDetection.detectAll();
    this.state.capabilities = this.featureDetection.capabilities();

    // Check online status
    if (this.platformBridge) {
      this.state.online = await this.platformBridge.isOnline();
    } else {
      this.state.online = navigator.onLine;
    }

    this.log('EngineFramework initialized', this.state);
  }

  /**
   * Get current framework state.
   * @returns {EngineFrameworkState} Copy of current state.
   */
  getState(): EngineFrameworkState {
    return { ...this.state };
  }

  /**
   * Get feature detection service.
   * @returns {FeatureDetectionService}
   */
  getFeatureDetection(): FeatureDetectionService {
    return this.featureDetection;
  }

  /**
   * Check if a feature is available.
   * @param {string} featureName - Feature identifier (e.g. 'file-system', 'notifications').
   * @returns {boolean}
   */
  has(featureName: string): boolean {
    return this.featureDetection.has(featureName);
  }

  /**
   * Get platform capabilities.
   * @returns {PlatformCapabilities}
   */
  getCapabilities(): PlatformCapabilities {
    return this.state.capabilities;
  }

  /**
   * Check if AI is available via platform bridge.
   * @returns {Promise<boolean>} True if bridge is present and AI is available.
   */
  async isAIAvailable(): Promise<boolean> {
    if (!this.platformBridge) {
      return false;
    }

    try {
      return await this.platformBridge.ai.isAvailable();
    } catch (error) {
      return false;
    }
  }

  /**
   * Perform AI text generation via platform bridge.
   * @param {string} prompt - Text prompt for generation.
   * @param {*} [options] - Optional generation options.
   * @returns {Promise<*>} Generation result from bridge.
   * @throws {Error} When platform bridge is not available.
   */
  async aiTextGeneration(prompt: string, options?: any): Promise<any> {
    if (!this.platformBridge) {
      throw new Error('Platform bridge not available');
    }

    return await this.platformBridge.ai.textGeneration({ prompt }, options);
  }

  /**
   * Get detected features (all, including unavailable).
   * @returns {DetectedFeature[]}
   */
  getFeatures(): DetectedFeature[] {
    return this.featureDetection.detectAll();
  }

  /**
   * Get only available/enabled features.
   * @returns {DetectedFeature[]}
   */
  getAvailableFeatures(): DetectedFeature[] {
    return this.featureDetection.detectEnabled();
  }

  /**
   * Get features grouped by category.
   * @returns {Record<string, DetectedFeature[]>}
   */
  byCategory(): Record<string, DetectedFeature[]> {
    return this.featureDetection.byCategory();
  }

  /**
   * Get feature statistics (total, available, unavailable, byCategory).
   * @returns {{ total: number, available: number, unavailable: number, byCategory: Record<string, number> }}
   */
  stats() {
    return this.featureDetection.stats();
  }

  /**
   * Update platform bridge (and feature detection).
   * @param {BridgeImpl} bridge - New platform bridge instance.
   */
  updateBridge(bridge: BridgeImpl): void {
    this.platformBridge = bridge;
    this.featureDetection.updateBridge(bridge);
    this.log('Platform bridge updated');
  }

  /**
   * Get platform identifier.
   * @returns {string}
   */
  getPlatform(): string {
    return this.platform;
  }

  /**
   * Check if platform reports online.
   * @returns {boolean}
   */
  isOnline(): boolean {
    return this.state.online;
  }

  /**
   * Get current platform bridge, if any.
   * @returns {BridgeImpl | undefined}
   */
  getPlatformBridge(): BridgeImpl | undefined {
    return this.platformBridge;
  }

  private log(message: string, data?: any): void {
    if (this.logger) {
      this.logger.log(`[EngineFramework] ${message}`, data);
    }
  }
}
