/**
 * @fileoverview Feature utilities - Filter, sort, and count helpers for detected features.
 */
import type { DetectedFeature, FeatureCategory } from '@meanwhile-together/shared';

/**
 * Filter features by category.
 * @param {DetectedFeature[]} features - List to filter.
 * @param {FeatureCategory} category - Category to keep.
 * @returns {DetectedFeature[]}
 */
export function filterFeaturesByCategory(features: DetectedFeature[], category: FeatureCategory): DetectedFeature[] {
  return features.filter(feature => feature.category === category);
}

/**
 * Filter features by availability.
 * @param {DetectedFeature[]} features - List to filter.
 * @param {boolean} available - Keep only available (true) or unavailable (false).
 * @returns {DetectedFeature[]}
 */
export function filterFeaturesByAvailability(features: DetectedFeature[], available: boolean): DetectedFeature[] {
  return features.filter(feature => feature.available === available);
}

/**
 * Sort features by displayName (mutates array).
 * @param {DetectedFeature[]} features - List to sort.
 * @returns {DetectedFeature[]}
 */
export function sortFeaturesByName(features: DetectedFeature[]): DetectedFeature[] {
  return features.sort((a, b) => a.displayName.localeCompare(b.displayName));
}

/**
 * Sort features by category order: platform-native, native-webapi, web-fallback, fallback.
 * @param {DetectedFeature[]} features - List to sort (mutated).
 * @returns {DetectedFeature[]}
 */
export function sortFeaturesByCategory(features: DetectedFeature[]): DetectedFeature[] {
  const categoryOrder: FeatureCategory[] = ['platform-native', 'native-webapi', 'web-fallback', 'fallback'];
  return features.sort((a, b) => {
    const aIndex = categoryOrder.indexOf(a.category);
    const bIndex = categoryOrder.indexOf(b.category);
    return aIndex - bIndex;
  });
}

/**
 * Get count of features per category.
 * @param {DetectedFeature[]} features - List to count.
 * @returns {Record<FeatureCategory, number>}
 */
export function getFeatureCountByCategory(features: DetectedFeature[]): Record<FeatureCategory, number> {
  const counts: Record<FeatureCategory, number> = {
    'platform-native': 0,
    'native-webapi': 0,
    'web-fallback': 0,
    'web-native-hybrid': 0,
    fallback: 0,
  };

  for (const feature of features) {
    counts[feature.category]++;
  }

  return counts;
}

/**
 * Check if any of the features are available.
 * @param {DetectedFeature[]} features - List to check.
 * @returns {boolean}
 */
export function hasAnyFeatures(features: DetectedFeature[]): boolean {
  return features.some(feature => feature.available);
}

/**
 * Get unique feature names from the list.
 * @param {DetectedFeature[]} features - List to scan.
 * @returns {string[]}
 */
export function getUniqueFeatureNames(features: DetectedFeature[]): string[] {
  const names = new Set<string>();
  for (const feature of features) {
    names.add(feature.name);
  }
  return Array.from(names);
}
