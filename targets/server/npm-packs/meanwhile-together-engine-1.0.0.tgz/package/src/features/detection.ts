/**
 * @fileoverview Feature Detection Service - Platform-agnostic detection of capabilities (file-system, notifications, AI, etc.).
 */
import type { PlatformBridgeImpl, DetectedFeature, FeatureDetectionConfig, PlatformCapabilities } from '@meanwhile-together/shared';
import { detectFeature, getAllFeatures } from './registry';

/**
 * Service that detects platform features using the registry and optional bridge.
 */
export class FeatureDetectionService {
  private platformBridge?: PlatformBridgeImpl;
  private platform: string;

  /**
   * @param {PlatformBridgeImpl} [platformBridge] - Optional bridge for native capability checks.
   * @param {string} [platform='web'] - Platform identifier.
   * @param {FeatureDetectionConfig} [_config] - Unused; reserved for future options.
   */
  constructor(platformBridge?: PlatformBridgeImpl, platform: string = 'web', _config: FeatureDetectionConfig = {}) {
    this.platformBridge = platformBridge;
    this.platform = platform;
  }

  /**
   * Detect all features (available and unavailable) for the current platform.
   * @returns {DetectedFeature[]}
   */
  detectAll(): DetectedFeature[] {
    const detectedFeatures: DetectedFeature[] = [];
    const allFeatures = getAllFeatures(this.platform);
    
    for (const feature of allFeatures) {
      const detection = detectFeature(this.platformBridge || {}, feature.name, this.platform);
      detectedFeatures.push({
        name: feature.name,
        displayName: feature.displayName,
        available: detection.available,
        category: detection.category,
        isNative: detection.isNative,
        isFallback: detection.isFallback,
        description: feature.description
      });
    }

    return detectedFeatures;
  }

  /**
   * Detect only enabled/available features.
   * @returns {DetectedFeature[]}
   */
  detectEnabled(): DetectedFeature[] {
    return this.detectAll().filter(feature => feature.available);
  }

  /**
   * Check if a specific feature is available.
   * @param {string} featureName - Feature identifier (e.g. 'file-system', 'notifications').
   * @returns {boolean}
   */
  has(featureName: string): boolean {
    const detection = detectFeature(this.platformBridge || {}, featureName, this.platform);
    return detection.available;
  }

  /**
   * Get features grouped by category.
   * @returns {Record<string, DetectedFeature[]>}
   */
  byCategory(): Record<string, DetectedFeature[]> {
    const features = this.detectAll();
    const categories: Record<string, DetectedFeature[]> = {
      'platform-native': [],
      'web-native-hybrid': [],
      'native-webapi': [],
      'web-fallback': [],
      'fallback': []
    };

    for (const feature of features) {
      if (!categories[feature.category]) {
        categories[feature.category] = [];
      }
      categories[feature.category].push(feature);
    }

    return categories;
  }

  /**
   * Get platform capabilities (hasFileSystem, hasNotifications, etc.).
   * @returns {PlatformCapabilities}
   */
  capabilities(): PlatformCapabilities {
    return {
      hasFileSystem: this.has('file-system'),
      hasNotifications: this.has('notifications'),
      hasFullscreen: this.has('fullscreen'),
      hasPersistentStorage: this.has('persistent-storage'),
      hasAiInference: this.has('ai-inference-cloud') || this.has('ai-inference-local'),
      hasGeolocation: this.has('geolocation'),
      hasCamera: this.has('camera'),
      hasMicrophone: this.has('microphone'),
      hasBluetooth: this.has('bluetooth'),
      hasNFC: this.has('nfc'),
      hasBiometrics: this.has('biometrics'),
      hasAutoStart: this.has('auto-start'),
      hasSaveDialog: this.has('save-dialog'),
      hasOpenFile: this.has('open-file'),
      hasShowInFolder: this.has('show-in-folder')
    };
  }

  /**
   * Get feature statistics (total, available, unavailable, byCategory).
   * @returns {{ total: number, available: number, unavailable: number, byCategory: Record<string, number> }}
   */
  stats(): {
    total: number;
    available: number;
    unavailable: number;
    byCategory: Record<string, number>;
  } {
    const features = this.detectAll();
    const byCategory: Record<string, number> = {};
    
    let available = 0;
    let unavailable = 0;

    for (const feature of features) {
      if (feature.available) {
        available++;
      } else {
        unavailable++;
      }

      if (!byCategory[feature.category]) {
        byCategory[feature.category] = 0;
      }
      byCategory[feature.category]++;
    }

    return {
      total: features.length,
      available,
      unavailable,
      byCategory
    };
  }

  /** @returns {string} Platform identifier. */
  getPlatform(): string {
    return this.platform;
  }

  /**
   * Update the platform bridge used for detection.
   * @param {PlatformBridgeImpl} bridge - New bridge.
   */
  updateBridge(bridge: PlatformBridgeImpl): void {
    this.platformBridge = bridge;
  }


}
