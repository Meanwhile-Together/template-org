/**
 * @fileoverview Feature Registry - Central registry of all detectable features (geolocation, camera, file-system, AI, etc.).
 */
import type { FeatureDefinition, FeatureRegistry } from '@meanwhile-together/shared';

function makeHybridFeature(
  name: string,
  displayName: string,
  testFunction: string,
  description: string,
  platform: 'all' | 'desktop' | 'mobile' | 'web' = 'all'
): FeatureDefinition {
  return {
    name,
    displayName,
    testFunction,
    category: 'web-native-hybrid',
    description,
    platform
  };
}

/**
 * Master feature registry: defines all possible features with name, testFunction, category, platform.
 */
export const FEATURE_REGISTRY: FeatureRegistry = {
  // Web+Native hybrid features (can be platform-native OR web API)
  'geolocation': makeHybridFeature('geolocation', 'Geolocation', 'getCurrentPosition', 'GPS location access'),
  'camera': makeHybridFeature('camera', 'Camera', 'getUserMedia', 'Camera access'),
  'microphone': makeHybridFeature('microphone', 'Microphone', 'getUserMedia', 'Microphone access'),
  'bluetooth': makeHybridFeature('bluetooth', 'Bluetooth', 'requestDevice', 'Bluetooth device access'),
  'notifications': makeHybridFeature('notifications', 'Notifications', 'showNotification', 'Platform notifications'),
  'fullscreen': makeHybridFeature('fullscreen', 'Fullscreen', 'requestFullscreen', 'Fullscreen mode support'),
  'persistent-storage': makeHybridFeature(
    'persistent-storage',
    'Persistent Storage',
    'requestPersistentStorage',
    'Persistent storage permissions'
  ),
  // Browser File System Access API + desktop bridge folder picker.
  'file-system': makeHybridFeature('file-system', 'File System', 'selectFolder', 'Native/web file system access'),
  'battery': makeHybridFeature('battery', 'Battery', 'getBatteryInfo', 'Battery level and charging state'),
  'network-info': makeHybridFeature('network-info', 'Network Info', 'getNetworkInfo', 'Network conditions and connectivity details'),
  'vibration': makeHybridFeature('vibration', 'Vibration', 'vibrate', 'Haptic vibration support'),
  'webgl': makeHybridFeature('webgl', 'WebGL', 'webgl', 'GPU-accelerated graphics API support'),
  'workers': makeHybridFeature('workers', 'Web Workers', 'workers', 'Background worker thread support'),
  'service-workers': makeHybridFeature('service-workers', 'Service Workers', 'serviceWorkers', 'Offline/background worker support'),
  'device-orientation': makeHybridFeature('device-orientation', 'Device Orientation', 'getDeviceOrientation', 'Device motion/orientation sensor support'),
  
  // Platform-native only (desktop)
  'auto-start': {
    name: 'auto-start',
    displayName: 'Auto Start',
    testFunction: 'setAutoStart',
    category: 'platform-native',
    description: 'System auto-start configuration',
    platform: 'desktop'
  },
  'save-dialog': {
    name: 'save-dialog',
    displayName: 'Save Dialog',
    testFunction: 'showSaveDialog',
    category: 'platform-native',
    description: 'Native save file dialog',
    platform: 'desktop'
  },
  'show-in-folder': {
    name: 'show-in-folder',
    displayName: 'Show in Folder',
    testFunction: 'showInFolder',
    category: 'platform-native',
    description: 'Show file in system folder',
    platform: 'desktop'
  },
  'open-file': {
    name: 'open-file',
    displayName: 'Open File',
    testFunction: 'openFile',
    category: 'platform-native',
    description: 'Open file with system default',
    platform: 'desktop'
  },
  
  // Platform-native only (mobile)
  'permissions': {
    name: 'permissions',
    displayName: 'Permissions',
    testFunction: 'requestPermissions',
    category: 'platform-native',
    description: 'Platform permission management',
    platform: 'mobile'
  },
  'nfc': {
    name: 'nfc',
    displayName: 'NFC',
    testFunction: 'requestDevice',
    category: 'platform-native',
    description: 'Near Field Communication',
    platform: 'mobile'
  },
  'biometrics': {
    ...makeHybridFeature('biometrics', 'Biometrics', 'webauthn', 'WebAuthn/passkey authentication support'),
    platform: 'all'
  },
  
  // AI features (hybrid - can be cloud or local)
  'ai-inference-cloud': makeHybridFeature(
    'ai-inference-cloud',
    'AI Inference (Cloud)',
    'aiInference',
    'Cloud-based AI inference'
  ),
  'ai-inference-local': makeHybridFeature(
    'ai-inference-local',
    'AI Inference (Local)',
    'aiInference',
    'Local AI inference'
  ),
};


// Helper: Check if bridge has overridden the base implementation
function isMethodOverridden(bridge: any, methodName: string): boolean {
  if (!(methodName in bridge)) return false;
  
  const bridgeProto = Object.getPrototypeOf(bridge);
  const baseProto = Object.getPrototypeOf(bridgeProto);
  
  // Check if method is overridden in platform implementation
  return bridgeProto.hasOwnProperty(methodName) || 
         (bridgeProto[methodName] !== baseProto[methodName]);
}

// Helper: Check if web API is available in runtime
function isWebAPIAvailable(testFunction: string): boolean {
  switch (testFunction) {
    case 'getCurrentPosition':
      return typeof navigator !== 'undefined' && 'geolocation' in navigator;
    case 'getUserMedia':
      return typeof navigator !== 'undefined' && 'mediaDevices' in navigator && 
             'getUserMedia' in navigator.mediaDevices;
    case 'requestFullscreen':
      return typeof document !== 'undefined' && 'requestFullscreen' in document.documentElement;
    case 'showNotification':
      return typeof window !== 'undefined' && 'Notification' in window;
    case 'requestDevice':
      return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
    case 'getBattery':
    case 'getBatteryInfo':
      return typeof navigator !== 'undefined' && 'getBattery' in navigator;
    case 'vibrate':
      return typeof navigator !== 'undefined' && 'vibrate' in navigator;
    case 'getNetworkInfo':
      return typeof navigator !== 'undefined' && 'connection' in navigator;
    case 'getDeviceOrientation':
      return typeof window !== 'undefined' && 'DeviceOrientationEvent' in window;
    case 'webgl':
      return typeof document !== 'undefined' && !!document.createElement('canvas').getContext('webgl');
    case 'workers':
      return typeof window !== 'undefined' && 'Worker' in window;
    case 'serviceWorkers':
      return typeof navigator !== 'undefined' && 'serviceWorker' in navigator;
    case 'requestPersistentStorage':
      return typeof navigator !== 'undefined' && 'storage' in navigator && 'persist' in navigator.storage;
    case 'webauthn':
      return typeof window !== 'undefined' && 'PublicKeyCredential' in window;
    default:
      return false;
  }
}

/**
 * Detect a single feature against a bridge and platform.
 * @param {*} bridge - Platform bridge (or empty object).
 * @param {string} featureName - Feature key from FEATURE_REGISTRY.
 * @param {string} [platform] - Platform (e.g. 'web', 'desktop').
 * @returns {{ available: boolean, category: string, isNative: boolean, isFallback: boolean }}
 */
export const detectFeature = (
  bridge: any,
  featureName: string,
  platform?: string
): {
  available: boolean;
  category: 'platform-native' | 'web-native-hybrid' | 'native-webapi' | 'web-fallback' | 'fallback';
  isNative: boolean;
  isFallback: boolean;
} => {
  const feature = FEATURE_REGISTRY[featureName];
  if (!feature) {
    return { available: false, category: 'fallback', isNative: false, isFallback: true };
  }

  const testFunction = feature.testFunction;
  
  // Special handling for AI inference
  if (featureName.startsWith('ai-inference-')) {
    if (bridge.ai && typeof bridge.ai.textGeneration === 'function') {
      if (feature.category === 'web-native-hybrid') {
        return {
          available: true,
          category: 'web-native-hybrid',
          isNative: platform === 'web',
          isFallback: platform !== 'web'
        };
      }
      return { available: true, category: 'platform-native', isNative: true, isFallback: false };
    }
    return { available: false, category: 'fallback', isNative: false, isFallback: true };
  }

  // Check if platform has overridden with native implementation
  const isOverridden = isMethodOverridden(bridge, testFunction);
  const hasWebAPI = isWebAPIAvailable(testFunction);

  // 1. Platform has overridden with a native implementation.
  if (isOverridden) {
    return {
      available: true,
      category: feature.category === 'web-native-hybrid' ? 'web-native-hybrid' : 'platform-native',
      isNative: true,
      isFallback: false
    };
  }

  // 2. Web API is available (from base Bridge class)
  if (hasWebAPI) {
    // Hybrid layer remains one layer while still tracking fallback semantics.
    if (feature.category === 'web-native-hybrid') {
      return {
        available: true,
        category: 'web-native-hybrid',
        isNative: platform === 'web',
        isFallback: platform !== 'web'
      };
    }

    // Determine if this is native or fallback based on platform
    if (platform === 'web') {
      return {
        available: true,
        category: 'native-webapi',
        isNative: true,
        isFallback: false
      };
    } else {
      // Non-web platform using web API = fallback
      return {
        available: true,
        category: 'web-fallback',
        isNative: false,
        isFallback: true
      };
    }
  }

  // 3. Not available
  return {
    available: false,
    category: 'fallback',
    isNative: false,
    isFallback: true
  };
};

/**
 * Get all feature definitions for a platform (or all if platform omitted).
 * @param {string} [platform] - Filter by platform ('web', 'desktop', 'mobile', 'all').
 * @returns {FeatureDefinition[]}
 */
export const getAllFeatures = (platform?: string): FeatureDefinition[] => {
  return Object.values(FEATURE_REGISTRY).filter(feature => {
    if (!platform) return true;
    return !feature.platform || feature.platform === 'all' || feature.platform === platform;
  });
};

/**
 * Get hybrid features that can use web APIs.
 * @returns {FeatureDefinition[]}
 */
export const getWebApiFeatures = (): FeatureDefinition[] => {
  return Object.values(FEATURE_REGISTRY).filter(feature => feature.category === 'web-native-hybrid');
};
