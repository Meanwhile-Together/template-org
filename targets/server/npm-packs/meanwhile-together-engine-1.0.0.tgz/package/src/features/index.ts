/**
 * @fileoverview Features module - Feature detection service, registry, and utilities.
 */
export { FeatureDetectionService } from './detection';

// Feature registry and definitions
export * from './registry';

// Feature utilities
export * from './utils';