/**
 * @fileoverview Jest tests for EngineFramework (constructor, initialize, state, has, capabilities, AI, features, bridge, platform).
 */

import { EngineFramework, type EngineFrameworkConfig } from './engine';
import type { BridgeImpl } from '@meanwhile-together/shared';

// Mock bridge implementation for testing
// Create a class to ensure proper prototype chain
class MockBridge {
  getPlatformType = jest.fn(() => 'web' as const);
  getPlatformInfo = jest.fn(async () => ({ platform: 'web', arch: 'x64', version: '1.0.0' }));
  isOnline = jest.fn(async () => true);
  showNotification = jest.fn(async () => {});
  getCurrentPosition = jest.fn(async () => ({
    coords: {
      latitude: 0, longitude: 0, accuracy: 0,
      altitude: null, altitudeAccuracy: null, heading: null, speed: null
    },
    timestamp: Date.now()
  }));
  getUserMedia = jest.fn(async () => ({} as MediaStream));
  getBatteryInfo = jest.fn(async () => ({ level: 1, charging: false, chargingTime: 0, dischargingTime: 0 }));
  getNetworkInfo = jest.fn(async () => ({ effectiveType: '4g', downlink: 10, rtt: 50, saveData: false }));
  getDeviceOrientation = jest.fn(async () => ({ alpha: null, beta: null, gamma: null }));
  vibrate = jest.fn();
  requestDevice = jest.fn(async () => ({} as any));
  requestFullscreen = jest.fn(async () => {});
  requestPersistentStorage = jest.fn(async () => true);
  isFileSystemAccessSupported = jest.fn(() => true);
  isBluetoothAvailable = jest.fn(async () => false);
  selectFolder = jest.fn(async () => null);
  openFile = jest.fn(async () => {});
  showInFolder = jest.fn(async () => {});
  showSaveDialog = jest.fn(async () => null);
  setAutoStart = jest.fn(async () => {});
  isAutoStartEnabled = jest.fn(async () => false);
  getBluetoothDevices = jest.fn(async () => []);
  requestPermissions = jest.fn(async () => ({}));
  getBatteryLevel = jest.fn(async () => 1);
  isCharging = jest.fn(async () => false);
  readFile = jest.fn(async () => '');
  writeFile = jest.fn(async () => {});
  exists = jest.fn(async () => false);
  getProcessInfo = jest.fn(async () => ({
    pid: 0, memoryUsage: {} as NodeJS.MemoryUsage, cpuUsage: {} as NodeJS.CpuUsage, uptime: 0
  }));
  getSystemInfo = jest.fn(async () => ({
    platform: 'web', arch: 'x64', version: '1.0.0', totalMemory: 0, freeMemory: 0, cpus: 0
  }));
  ai = {
    getCapabilities: jest.fn(async () => ({ cloud: false, local: false })),
    isAvailable: jest.fn(async () => false),
    healthCheck: jest.fn(async () => ({})),
    configure: jest.fn(),
    getConfig: jest.fn(() => ({})),
    textGeneration: jest.fn(async () => ({})),
    textClassification: jest.fn(async () => ({})),
    translation: jest.fn(async () => ({})),
    summarization: jest.fn(async () => ({})),
    questionAnswering: jest.fn(async () => ({})),
    fillMask: jest.fn(async () => ({})),
    sentenceSimilarity: jest.fn(async () => ({})),
    featureExtraction: jest.fn(async () => ({})),
    tokenClassification: jest.fn(async () => ({})),
    zeroShotClassification: jest.fn(async () => ({})),
    textToImage: jest.fn(async () => ({})),
    imageClassification: jest.fn(async () => ({})),
    imageToText: jest.fn(async () => ({})),
    automaticSpeechRecognition: jest.fn(async () => ({})),
    textToSpeech: jest.fn(async () => ({})),
    chatCompletion: jest.fn(async () => ({})),
    chatCompletionStream: jest.fn(async () => ({})),
    textGenerationStream: jest.fn(async () => ({}))
  } as any;
  features = {
    has: jest.fn(() => false),
    detectAll: jest.fn(() => []),
    detectEnabled: jest.fn(() => []),
    byCategory: jest.fn(() => ({})),
    capabilities: jest.fn(() => ({
      hasFileSystem: false, hasNotifications: false, hasFullscreen: false,
      hasPersistentStorage: false, hasAiInference: false, hasGeolocation: false,
      hasCamera: false, hasMicrophone: false, hasBluetooth: false,
      hasNFC: false, hasBiometrics: false, hasAutoStart: false,
      hasSaveDialog: false, hasOpenFile: false, hasShowInFolder: false
    })),
    stats: jest.fn(() => ({
      total: 0, available: 0, unavailable: 0, byCategory: {}
    })),
    platform: jest.fn(() => 'web'),
    updateBridge: jest.fn()
  };
}

const createMockBridge = (): BridgeImpl => {
  return new MockBridge() as unknown as BridgeImpl;
};

describe('EngineFramework', () => {
  describe('constructor', () => {
    it('should initialize with default config', () => {
      const engine = new EngineFramework();
      
      expect(engine.getPlatform()).toBe('web');
      expect(engine.getState().platform).toBe('web');
      expect(engine.getState().features).toEqual([]);
      expect(engine.getState().online).toBe(true);
    });

    it('should initialize with custom platform', () => {
      const engine = new EngineFramework({ platform: 'desktop' });
      
      expect(engine.getPlatform()).toBe('desktop');
      expect(engine.getState().platform).toBe('desktop');
    });

    it('should initialize with platform bridge', () => {
      const mockBridge = createMockBridge();
      const engine = new EngineFramework({ 
        platformBridge: mockBridge 
      });
      
      expect(engine.getPlatformBridge()).toBe(mockBridge);
    });

    it('should initialize with logging enabled', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      const engine = new EngineFramework({ enableLogging: true });
      
      expect(consoleSpy).toHaveBeenCalled();
      consoleSpy.mockRestore();
    });
  });

  describe('initialize', () => {
    it('should initialize and detect features', async () => {
      const engine = new EngineFramework();
      await engine.initialize();
      
      const state = engine.getState();
      expect(state).toBeDefined();
      expect(Array.isArray(state.features)).toBe(true);
      expect(state.capabilities).toBeDefined();
    });

    it('should set online status from bridge', async () => {
      const mockBridge = createMockBridge();
      (mockBridge.isOnline as jest.Mock).mockResolvedValue(false);
      
      const engine = new EngineFramework({ platformBridge: mockBridge });
      await engine.initialize();
      
      expect(engine.isOnline()).toBe(false);
    });

    it('should set online status from navigator when no bridge', async () => {
      // Mock navigator.onLine
      Object.defineProperty(global, 'navigator', {
        value: { onLine: false },
        writable: true,
        configurable: true
      });
      
      const engine = new EngineFramework();
      await engine.initialize();
      
      expect(engine.isOnline()).toBe(false);
    });
  });

  describe('getState', () => {
    it('should return a copy of the current state', () => {
      const engine = new EngineFramework();
      const state1 = engine.getState();
      const state2 = engine.getState();
      
      expect(state1).toEqual(state2);
      expect(state1).not.toBe(state2); // Should be a copy, not the same reference
    });
  });

  describe('has', () => {
    it('should check if a feature is available', () => {
      const engine = new EngineFramework();
      // The actual behavior depends on feature detection implementation
      expect(typeof engine.has('file-system')).toBe('boolean');
    });
  });

  describe('getCapabilities', () => {
    it('should return platform capabilities', () => {
      const engine = new EngineFramework();
      const capabilities = engine.getCapabilities();
      
      expect(capabilities).toBeDefined();
      expect(typeof capabilities.hasFileSystem).toBe('boolean');
      expect(typeof capabilities.hasNotifications).toBe('boolean');
      expect(typeof capabilities.hasFullscreen).toBe('boolean');
    });
  });

  describe('isAIAvailable', () => {
    it('should return false when no bridge is available', async () => {
      const engine = new EngineFramework();
      const available = await engine.isAIAvailable();
      
      expect(available).toBe(false);
    });

    it('should return AI availability from bridge', async () => {
      const mockBridge = createMockBridge();
      (mockBridge.ai.isAvailable as jest.Mock).mockResolvedValue(true);
      
      const engine = new EngineFramework({ platformBridge: mockBridge });
      const available = await engine.isAIAvailable();
      
      expect(available).toBe(true);
    });

    it('should return false on error', async () => {
      const mockBridge = createMockBridge();
      (mockBridge.ai.isAvailable as jest.Mock).mockRejectedValue(new Error('AI not available'));
      
      const engine = new EngineFramework({ platformBridge: mockBridge });
      const available = await engine.isAIAvailable();
      
      expect(available).toBe(false);
    });
  });

  describe('aiTextGeneration', () => {
    it('should throw error when no bridge is available', async () => {
      const engine = new EngineFramework();
      
      await expect(engine.aiTextGeneration('test prompt')).rejects.toThrow(
        'Platform bridge not available'
      );
    });

    it('should call bridge AI text generation', async () => {
      const mockBridge = createMockBridge();
      const mockResponse = { text: 'generated text' };
      (mockBridge.ai.textGeneration as jest.Mock).mockResolvedValue(mockResponse);
      
      const engine = new EngineFramework({ platformBridge: mockBridge });
      const result = await engine.aiTextGeneration('test prompt');
      
      expect(mockBridge.ai.textGeneration).toHaveBeenCalledWith(
        { prompt: 'test prompt' },
        undefined
      );
      expect(result).toEqual(mockResponse);
    });

    it('should pass options to bridge AI', async () => {
      const mockBridge = createMockBridge();
      const options = { temperature: 0.7 };
      (mockBridge.ai.textGeneration as jest.Mock).mockResolvedValue({});
      
      const engine = new EngineFramework({ platformBridge: mockBridge });
      await engine.aiTextGeneration('test prompt', options);
      
      expect(mockBridge.ai.textGeneration).toHaveBeenCalledWith(
        { prompt: 'test prompt' },
        options
      );
    });
  });

  describe('getFeatures', () => {
    it('should return all detected features', () => {
      const engine = new EngineFramework();
      const features = engine.getFeatures();
      
      expect(Array.isArray(features)).toBe(true);
    });
  });

  describe('getAvailableFeatures', () => {
    it('should return only available features', () => {
      const engine = new EngineFramework();
      const features = engine.getAvailableFeatures();
      
      expect(Array.isArray(features)).toBe(true);
      // All returned features should be available
      features.forEach(feature => {
        expect(feature.available).toBe(true);
      });
    });
  });

  describe('byCategory', () => {
    it('should return features grouped by category', () => {
      const engine = new EngineFramework();
      const categorized = engine.byCategory();
      
      expect(typeof categorized).toBe('object');
      expect(Array.isArray(categorized['platform-native'])).toBe(true);
    });
  });

  describe('stats', () => {
    it('should return feature statistics', () => {
      const engine = new EngineFramework();
      const stats = engine.stats();
      
      expect(stats).toHaveProperty('total');
      expect(stats).toHaveProperty('available');
      expect(stats).toHaveProperty('unavailable');
      expect(stats).toHaveProperty('byCategory');
      expect(typeof stats.total).toBe('number');
      expect(typeof stats.available).toBe('number');
      expect(typeof stats.unavailable).toBe('number');
    });
  });

  describe('updateBridge', () => {
    it('should update the platform bridge', () => {
      const engine = new EngineFramework();
      const newBridge = createMockBridge();
      
      engine.updateBridge(newBridge);
      
      expect(engine.getPlatformBridge()).toBe(newBridge);
    });
  });

  describe('getPlatform', () => {
    it('should return the current platform', () => {
      const engine = new EngineFramework({ platform: 'mobile' });
      
      expect(engine.getPlatform()).toBe('mobile');
    });
  });

  describe('isOnline', () => {
    it('should return online status', () => {
      const engine = new EngineFramework();
      
      expect(typeof engine.isOnline()).toBe('boolean');
    });
  });

  describe('getFeatureDetection', () => {
    it('should return the feature detection service', () => {
      const engine = new EngineFramework();
      const featureDetection = engine.getFeatureDetection();
      
      expect(featureDetection).toBeDefined();
      expect(featureDetection).toHaveProperty('detectAll');
      expect(featureDetection).toHaveProperty('has');
      expect(featureDetection).toHaveProperty('capabilities');
    });
  });
});

