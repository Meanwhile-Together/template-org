/**
 * @fileoverview Mobile platform bridge. Uses proxy browser service (WebSocket to server).
 */
import type { MobileBridge, BrowserServiceConfig } from '@meanwhile-together/shared';
import { Bridge } from '../bridge';
import { createProxyBrowserService } from '../../browser/proxy-browser-service';

/**
 * Mobile platform bridge. Inherits web APIs from Bridge; browser via ProxyBrowserService.
 */
export class MobileBridgeImpl extends Bridge implements MobileBridge {
  private browserConfig?: BrowserServiceConfig;

  /**
   * @param {*} [aiConfig] - AI inferer config.
   * @param {BrowserServiceConfig} [browserConfig] - Browser service config.
   */
  constructor(aiConfig?: any, browserConfig?: BrowserServiceConfig) {
    super(aiConfig);
    this.browserConfig = browserConfig;
    // Mobile can optionally use native AI implementations for better performance
    // For now, we inherit the web-based implementation from Bridge
    
    // Initialize browser service for Mobile platform (always proxy to server)
    this.initializeBrowser();
  }

  private initializeBrowser(): void {
    try {
      // Mobile platform always uses proxy browser service (cannot run Playwright locally)
      this.browser = createProxyBrowserService(this.browserConfig);
    } catch (error: any) {
      console.warn('[MobileBridge] Browser service initialization failed:', error.message);
      // Bridge will use stub browser service from base class
    }
  }

  /** @returns {'mobile'} */
  getPlatformType(): 'mobile' {
    return 'mobile';
  }

  // Mobile-native implementations (keep existing code)
  async requestPermissions(_permissions: string[]): Promise<Record<string, boolean>> {
    throw new Error('Mobile bridge not implemented');
  }

  async getBatteryLevel(): Promise<number> {
    throw new Error('Mobile bridge not implemented');
  }

  async isCharging(): Promise<boolean> {
    throw new Error('Mobile bridge not implemented');
  }

  // Remove all web API stubs (getCurrentPosition, getUserMedia, etc.)
  // They're now inherited from base Bridge class
  // Can optionally override with Capacitor plugins later
}