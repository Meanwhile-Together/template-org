import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { NodeBridgeImpl } from './node';

describe('NodeBridgeImpl platform methods', () => {
  const bridge = Object.create(NodeBridgeImpl.prototype) as NodeBridgeImpl;

  it('reads and writes files', async () => {
    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'node-bridge-test-'));
    const filePath = path.join(tempRoot, 'nested', 'sample.txt');
    await bridge.writeFile(filePath, 'hello-bridge');
    const content = await bridge.readFile(filePath);
    expect(content).toBe('hello-bridge');
  });

  it('checks file existence', async () => {
    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'node-bridge-exists-'));
    const filePath = path.join(tempRoot, 'exists.txt');
    expect(await bridge.exists(filePath)).toBe(false);
    fs.writeFileSync(filePath, 'x', 'utf8');
    expect(await bridge.exists(filePath)).toBe(true);
  });

  it('returns process info using process APIs', async () => {
    const memorySpy = jest.spyOn(process, 'memoryUsage').mockReturnValue({
      rss: 1,
      heapTotal: 2,
      heapUsed: 3,
      external: 4,
      arrayBuffers: 5,
    } as NodeJS.MemoryUsage);
    const cpuSpy = jest.spyOn(process, 'cpuUsage').mockReturnValue({ user: 10, system: 20 });
    const uptimeSpy = jest.spyOn(process, 'uptime').mockReturnValue(123);

    const info = await bridge.getProcessInfo();
    expect(info.pid).toBe(process.pid);
    expect(info.memoryUsage.heapUsed).toBe(3);
    expect(info.cpuUsage.user).toBe(10);
    expect(info.uptime).toBe(123);

    memorySpy.mockRestore();
    cpuSpy.mockRestore();
    uptimeSpy.mockRestore();
  });

  it('returns system info using os APIs', async () => {
    const info = await bridge.getSystemInfo();
    expect(info.platform).toBe(process.platform);
    expect(info.arch).toBe(process.arch);
    expect(info.version).toBe(os.release());
    expect(info.totalMemory).toBeGreaterThan(0);
    expect(info.freeMemory).toBeGreaterThan(0);
    expect(info.freeMemory).toBeLessThanOrEqual(info.totalMemory);
    expect(info.cpus).toBe(os.cpus().length);
  });
});
