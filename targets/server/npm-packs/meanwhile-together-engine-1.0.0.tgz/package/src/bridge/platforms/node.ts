/**
 * @fileoverview Node platform bridge. Uses unified/app database services and local browser service (Playwright).
 */
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { promises as fsp } from 'fs';
import type { NodeBridge, DatabaseServiceConfig, BrowserServiceConfig, ProcessInfo, SystemInfo } from '@meanwhile-together/shared';
import { Bridge } from '../bridge';
import { createUnifiedDatabaseService, createAppOnlyDatabaseService } from '../../database/unified-database-service';
import { createLocalBrowserService } from '../../browser/local-browser-service';

function inferRootFromMainScript(): string | null {
  const main = process.argv[1];
  if (!main) return null;
  const serverDistDir = path.dirname(path.resolve(main));
  // Infer repo root from .../targets/server/dist/index.js without requiring db/ (Prisma may be missing).
  const base = path.basename(serverDistDir);
  if (base !== 'dist') return null;
  const serverDir = path.dirname(serverDistDir);
  if (path.basename(serverDir) !== 'server') return null;
  const targetsDir = path.dirname(serverDir);
  if (path.basename(targetsDir) !== 'targets') return null;
  return path.resolve(targetsDir, '..');
}

function getProjectRootsForDb(): string[] {
  const out: string[] = [];
  const add = (p: string) => {
    const r = path.resolve(p);
    if (!out.includes(r)) out.push(r);
  };

  if (process.env.PROJECT_ROOT) {
    add(process.env.PROJECT_ROOT);
  }

  const fromMain = inferRootFromMainScript();
  if (fromMain) add(fromMain);

  add(process.cwd());
  return out;
}

/**
 * Load targets/server/dist/db/{app-client|backend-client} from engine (under node_modules or monorepo).
 * Never use a 5× .. path before resolving repo root — it maps to @meanwhile-together/targets/... under npm.
 */
function tryRequireDbModule(
  basename: 'app-client' | 'backend-client',
  accessor: 'getAppClient' | 'getBackendClient'
): any | null {
  const d = __dirname;
  const candidates: string[] = [];

  for (const root of getProjectRootsForDb()) {
    candidates.push(path.join(root, 'targets', 'server', 'dist', 'db', basename));
  }

  // Monorepo dev only: engine lives under project-bridge/engine/... — do not add paths under
  // node_modules/@meanwhile-together/targets/... (npm pack layout has no unified dist there).
  if (!d.includes(`${path.sep}node_modules${path.sep}`)) {
    candidates.push(
      path.join(d, '..', '..', '..', '..', '..', '..', '..', 'targets', 'server', 'dist', 'db', basename),
      path.join(d, '..', '..', '..', '..', '..', 'targets', 'server', 'dist', 'db', basename)
    );
  }

  const srcCandidates: string[] = [];
  for (const root of getProjectRootsForDb()) {
    const p = path.join(root, 'targets', 'server', 'src', 'db', basename);
    if (fs.existsSync(p + '.ts') || fs.existsSync(p + '.js')) {
      srcCandidates.push(p);
    }
  }

  let last: Error | null = null;
  for (const id of [...candidates, ...srcCandidates]) {
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const mod = require(id);
      const fn = mod[accessor];
      if (typeof fn === 'function') {
        return fn();
      }
    } catch (e: any) {
      last = e;
      const msg = e?.message ?? String(e);
      // Module loaded but getAppClient() failed (e.g. DATABASE_URL missing on Railway) — not a missing dist/db file.
      if (
        msg.includes('DATABASE_URL') ||
        msg.includes('DATABASE_PROVIDER') ||
        /environment variable is required/i.test(msg) ||
        msg.includes('PGHOST')
      ) {
        throw new Error(
          `${msg} ` +
            `Set DATABASE_URL in Railway (e.g. Postgres plugin reference variables) or use DATABASE_PROVIDER=sqlite for local file DB.`
        );
      }
    }
  }
  if (basename === 'backend-client') {
    return null;
  }
  const roots = getProjectRootsForDb();
  const expected = roots.length
    ? path.join(roots[0], 'targets', 'server', 'dist', 'db', `${basename}.js`)
    : path.join(process.cwd(), 'targets', 'server', 'dist', 'db', `${basename}.js`);
  throw new Error(
    `Failed to load app Prisma client. Expected generated file at ${expected} (run db:generate + build:server in project-bridge, then npm run prepare:railway). ` +
      `Detail: ${last?.message ?? 'unknown'}`
  );
}

function loadAppClient(): any {
  return tryRequireDbModule('app-client', 'getAppClient');
}

function loadBackendClient(): any | null {
  return tryRequireDbModule('backend-client', 'getBackendClient');
}

/**
 * Node platform bridge: app/backend DB (when allowed), local browser service, AI from config.
 */
export class NodeBridgeImpl extends Bridge implements NodeBridge {
  private dbConfig?: DatabaseServiceConfig;
  private browserConfig?: BrowserServiceConfig;

  /**
   * @param {*} [aiConfig] - AI inferer config.
   * @param {DatabaseServiceConfig} [dbConfig] - Database config (schema, allowBackendAccess, etc.).
   * @param {BrowserServiceConfig} [browserConfig] - Browser service config.
   */
  constructor(aiConfig?: any, dbConfig?: DatabaseServiceConfig, browserConfig?: BrowserServiceConfig) {
    super(aiConfig);
    this.dbConfig = dbConfig;
    this.browserConfig = browserConfig;
    // Initialize database service for Node platform
    this.initializeDatabase();
    // Initialize browser service for Node platform (direct Playwright execution)
    this.initializeBrowser();
  }

  private initializeBrowser(): void {
    try {
      // Node platform uses local browser service (direct Playwright)
      this.browser = createLocalBrowserService(this.browserConfig);
    } catch (error: any) {
      console.warn('[NodeBridge] Browser service initialization failed:', error.message);
      // Bridge will use stub browser service from base class
    }
  }

  private initializeDatabase(): void {
    try {
      // Always load app client (required)
      const appClient = loadAppClient();
      
      // Try to load backend client (optional, depends on context)
      const backendClient = loadBackendClient();
      
      // Determine if we should provide both schemas
      const schema = this.dbConfig?.schema || 'app';
      const wantsBoth = schema === 'both' || this.dbConfig?.allowBackendAccess === true || this.dbConfig?.allowAdminAccess === true;
      
      if (wantsBoth && backendClient) {
        // Create unified service with both app and backend access
        const dbService = createUnifiedDatabaseService(appClient, backendClient, {
          ...this.dbConfig,
          allowBackendAccess: true // Explicitly allow since we're providing both
        });
        this.db = dbService;
      } else if (backendClient && this.isBackendContext()) {
        // Auto-detect backend context and allow backend access
        const dbService = createUnifiedDatabaseService(appClient, backendClient, {
          ...this.dbConfig,
          allowBackendAccess: true
        });
        this.db = dbService;
      } else {
        // App-only service
        const dbService = createAppOnlyDatabaseService(appClient, this.dbConfig);
        this.db = dbService;
      }
    } catch (error: any) {
      // If database initialization fails, log warning but don't fail bridge creation
      console.warn('[NodeBridge] Database initialization failed:', error.message);
      console.warn('[NodeBridge] Bridge will continue with stub database service');
      // Bridge will use stub database service from base class
    }
  }

  /**
   * Checks if we're running in a backend context (backend-server)
   */
  private isBackendContext(): boolean {
    if (typeof require === 'undefined') {
      return false;
    }
    
    try {
      const mainModule = require.main;
      if (mainModule) {
        const filename = mainModule.filename || '';
        // Check if running from backend-server
        return filename.includes('backend-server') || 
               filename.includes('backend/server') ||
               process.env.BACKEND_SERVER === 'true' ||
               // Legacy support (deprecated, will be removed in future version)
               filename.includes('admin-server') ||
               process.env.ADMIN_SERVER === 'true';
      }
    } catch {
      // If we can't determine, default to false
    }
    
    return false;
  }

  /** @returns {'node'} */
  getPlatformType(): 'node' {
    return 'node';
  }

  // Node-specific implementations (keep as-is)
  async readFile(targetPath: string): Promise<string> {
    return await fsp.readFile(targetPath, 'utf8');
  }

  async writeFile(targetPath: string, content: string): Promise<void> {
    await fsp.mkdir(path.dirname(targetPath), { recursive: true });
    await fsp.writeFile(targetPath, content, 'utf8');
  }

  async exists(targetPath: string): Promise<boolean> {
    try {
      await fsp.access(targetPath);
      return true;
    } catch {
      return false;
    }
  }

  async getProcessInfo(): Promise<ProcessInfo> {
    return {
      pid: process.pid,
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage(),
      uptime: process.uptime(),
    };
  }

  async getSystemInfo(): Promise<SystemInfo> {
    return {
      platform: process.platform,
      arch: process.arch,
      version: os.release(),
      totalMemory: os.totalmem(),
      freeMemory: os.freemem(),
      cpus: os.cpus().length,
    };
  }
}