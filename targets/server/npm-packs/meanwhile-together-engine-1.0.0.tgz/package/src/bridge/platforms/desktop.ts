/**
 * @fileoverview Desktop platform bridge. Uses local browser service with optional proxy fallback.
 */
import type { DesktopBridge, BrowserServiceConfig } from '@meanwhile-together/shared';
import { Bridge } from '../bridge';
import { createLocalBrowserService } from '../../browser/local-browser-service';
import { createProxyBrowserService } from '../../browser/proxy-browser-service';

/**
 * Desktop platform bridge. Inherits web APIs from Bridge; browser via LocalBrowserService (+ optional proxy).
 */
export class DesktopBridgeImpl extends Bridge implements DesktopBridge {
  private browserConfig?: BrowserServiceConfig;

  /**
   * @param {*} [aiConfig] - AI inferer config.
   * @param {BrowserServiceConfig} [browserConfig] - Browser service config.
   */
  constructor(aiConfig?: any, browserConfig?: BrowserServiceConfig) {
    super(aiConfig);
    this.browserConfig = browserConfig;
    // Desktop can optionally use native AI implementations for better performance
    // For now, we inherit the web-based implementation from Bridge
    
    // Initialize browser service for Desktop platform
    // Desktop can run Playwright locally but can also use server via useServer(true)
    this.initializeBrowser();
  }

  private initializeBrowser(): void {
    try {
      // Create proxy service for optional server fallback
      const proxyService = createProxyBrowserService(this.browserConfig);
      
      // Desktop uses local browser service with proxy fallback option
      this.browser = createLocalBrowserService(this.browserConfig, proxyService);
    } catch (error: any) {
      console.warn('[DesktopBridge] Browser service initialization failed:', error.message);
      // Bridge will use stub browser service from base class
    }
  }

  /** @returns {'desktop'} */
  getPlatformType(): 'desktop' {
    return 'desktop';
  }

  // Desktop-native implementations (keep existing code)
  async selectFolder(): Promise<string | null> {
    throw new Error('Desktop bridge not implemented');
  }

  async openFile(_path: string): Promise<void> {
    throw new Error('Desktop bridge not implemented');
  }

  async showInFolder(_path: string): Promise<void> {
    throw new Error('Desktop bridge not implemented');
  }

  async showSaveDialog(_options?: any): Promise<string | null> {
    throw new Error('Desktop bridge not implemented');
  }

  async setAutoStart(_enabled: boolean): Promise<void> {
    throw new Error('Desktop bridge not implemented');
  }

  async isAutoStartEnabled(): Promise<boolean> {
    throw new Error('Desktop bridge not implemented');
  }

  async getBluetoothDevices(): Promise<any[]> {
    throw new Error('Desktop bridge not implemented');
  }

  // Remove all web API stubs (getCurrentPosition, getUserMedia, etc.)
  // They're now inherited from base Bridge class
  // Can optionally override with Capacitor/native implementations later
}