/**
 * @fileoverview Browser (web) platform bridge. Uses proxy browser service (WebSocket to server).
 */
import type { BrowserBridge, BrowserServiceConfig } from '@meanwhile-together/shared';
import { Bridge } from '../bridge';
import { createProxyBrowserService } from '../../browser/proxy-browser-service';

/**
 * Web platform bridge implementation. AI and features from base Bridge; browser via ProxyBrowserService.
 */
export class BrowserBridgeImpl extends Bridge implements BrowserBridge {
  private browserConfig?: BrowserServiceConfig;

  /**
   * @param {*} [aiConfig] - AI inferer config.
   * @param {BrowserServiceConfig} [browserConfig] - Browser service config (serverUrl, wsPath, etc.).
   */
  constructor(aiConfig?: any, browserConfig?: BrowserServiceConfig) {
    super(aiConfig);
    this.browserConfig = browserConfig;
    // Initialize browser service for Web platform (always proxy to server)
    this.initializeBrowser();
  }

  private initializeBrowser(): void {
    try {
      // Web platform always uses proxy browser service (cannot run Playwright locally)
      this.browser = createProxyBrowserService(this.browserConfig);
    } catch (error: any) {
      console.warn('[BrowserBridge] Browser service initialization failed:', error.message);
      // Bridge will use stub browser service from base class
    }
  }

  /** @returns {'web'} */
  getPlatformType(): 'web' {
    return 'web';
  }
  
  // All web API methods inherited from base Bridge class
  // No need to reimplement: getCurrentPosition, getUserMedia, etc.
}