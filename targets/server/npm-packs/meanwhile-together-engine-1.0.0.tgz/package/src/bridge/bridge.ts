/**
 * @fileoverview Base platform bridge implementation. Provides web-based defaults for AI, features, db, browser;
 * platform-specific bridges extend and override. FeatureServiceImpl delegates to FeatureDetectionService.
 */
import type {
  BridgeImpl,
  NotificationOptions,
  AIInfererImpl,
  AIInfererConfig,
  FeatureService,
  DetectedFeature,
  PlatformCapabilities,
  PlatformBridgeImpl,
  DatabaseService,
  BrowserService
} from '@meanwhile-together/shared';
import { FeatureDetectionService } from '../features/detection';
import { createAIInferer } from '../ai/ai-inferer';
import { createStubDatabaseService } from '../database/stub-database-service';
import { createStubBrowserService } from '../browser/stub-browser-service';

/**
 * FeatureService implementation that delegates to FeatureDetectionService.
 * @internal
 */
class FeatureServiceImpl implements FeatureService {
  private featureDetection: FeatureDetectionService;

  /** @param {FeatureDetectionService} featureDetection */
  constructor(featureDetection: FeatureDetectionService) {
    this.featureDetection = featureDetection;
  }

  has(name: string): boolean {
    return this.featureDetection.has(name);
  }

  detectAll(): DetectedFeature[] {
    return this.featureDetection.detectAll();
  }

  detectEnabled(): DetectedFeature[] {
    return this.featureDetection.detectEnabled();
  }

  byCategory(): Record<string, DetectedFeature[]> {
    return this.featureDetection.byCategory();
  }

  capabilities(): PlatformCapabilities {
    return this.featureDetection.capabilities();
  }

  stats(): { total: number; available: number; unavailable: number; byCategory: Record<string, number>; } {
    return this.featureDetection.stats();
  }

  platform(): string {
    return this.featureDetection.getPlatform();
  }

  updateBridge(bridge: PlatformBridgeImpl): void {
    this.featureDetection.updateBridge(bridge);
  }
}

/**
 * Base platform bridge: web-based AI, features, db (stub), browser (stub). Platforms extend and override.
 */
export abstract class Bridge implements BridgeImpl {
  public ai: AIInfererImpl;
  private _features?: FeatureService;
  private _db?: DatabaseService;
  private _browser?: BrowserService;

  /**
   * @param {AIInfererConfig} [aiConfig] - AI inferer configuration.
   */
  constructor(aiConfig?: AIInfererConfig) {
    this.ai = createAIInferer(aiConfig);
  }

  // Feature detection service - lazily initialized with current bridge instance
  get features(): FeatureService {
    if (!this._features) {
      const featureDetection = new FeatureDetectionService(this, this.getPlatformType());
      this._features = new FeatureServiceImpl(featureDetection);
    }
    return this._features;
  }

  // Database service - lazily initialized, defaults to stub for non-Node platforms
  get db(): DatabaseService {
    if (!this._db) {
      this._db = createStubDatabaseService();
    }
    return this._db;
  }

  set db(value: DatabaseService) {
    this._db = value;
  }

  // Browser service - lazily initialized, defaults to stub
  // Platform bridges should override with LocalBrowserService or ProxyBrowserService
  get browser(): BrowserService {
    if (!this._browser) {
      this._browser = createStubBrowserService();
    }
    return this._browser;
  }

  set browser(value: BrowserService) {
    this._browser = value;
  }

  /** @returns {'web'|'desktop'|'mobile'|'node'} Platform type (implemented by subclasses). */
  abstract getPlatformType(): 'web' | 'desktop' | 'mobile' | 'node';

  /**
   * @returns {Promise<any>} Platform info (platform, version, userAgent).
   */
  async getPlatformInfo(): Promise<any> {
    return {
      platform: this.getPlatformType(),
      version: '1.0.0',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Node.js'
    };
  }

  /** @returns {Promise<boolean>} Whether the platform is online. */
  async isOnline(): Promise<boolean> {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  }

  /**
   * Show a notification (uses Web Notifications API when available).
   * @param {string} title - Notification title.
   * @param {string} message - Notification body.
   * @param {NotificationOptions} [options] - Optional notification options.
   * @returns {Promise<void>}
   */
  async showNotification(title: string, message: string, options?: NotificationOptions): Promise<void> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification(title, { body: message, ...options });
        return;
      }
      if (Notification.permission === 'default') {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          new Notification(title, { body: message, ...options });
          return;
        }
      }
    }
    console.log(`[Notification] ${title}: ${message}`);
  }

  // === SHARED WEB API IMPLEMENTATIONS (platforms can override) ===
  
  /**
   * Get current geolocation position.
   * @returns {Promise<GeolocationPosition>}
   * @throws {Error} When geolocation is not available.
   */
  async getCurrentPosition(): Promise<GeolocationPosition> {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      throw new Error('Geolocation not available');
    }
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    });
  }

  /**
   * Get user media (camera/microphone).
   * @param {MediaStreamConstraints} constraints - Media constraints.
   * @returns {Promise<MediaStream>}
   * @throws {Error} When MediaDevices not available.
   */
  async getUserMedia(constraints: MediaStreamConstraints): Promise<MediaStream> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices) {
      throw new Error('MediaDevices not available');
    }
    return navigator.mediaDevices.getUserMedia(constraints);
  }

  /** @returns {Promise<any>} Battery info. @throws {Error} When Battery API not supported. */
  async getBatteryInfo(): Promise<any> {
    if (typeof navigator === 'undefined' || !('getBattery' in navigator)) {
      throw new Error('Battery API not supported');
    }
    return await (navigator as any).getBattery();
  }

  /** @returns {Promise<any>} Network connection info. @throws {Error} When Network Information API not supported. */
  async getNetworkInfo(): Promise<any> {
    if (typeof navigator === 'undefined' || !('connection' in navigator)) {
      throw new Error('Network Information API not supported');
    }
    return (navigator as any).connection;
  }

  /** @returns {Promise<any>} Device orientation (alpha, beta, gamma) or nulls if unavailable. */
  async getDeviceOrientation(): Promise<any> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !('DeviceOrientationEvent' in window)) {
        resolve({ alpha: null, beta: null, gamma: null });
        return;
      }
      window.addEventListener('deviceorientation', (event) => {
        resolve({ alpha: event.alpha, beta: event.beta, gamma: event.gamma });
      }, { once: true });
    });
  }

  /** @param {number|number[]} pattern - Vibration pattern. */
  vibrate(pattern: number | number[]): void {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  }

  /**
   * Request Bluetooth device.
   * @param {*} options - Request options.
   * @returns {Promise<any>}
   * @throws {Error} When Bluetooth API not supported.
   */
  async requestDevice(options: any): Promise<any> {
    if (typeof navigator === 'undefined' || !('bluetooth' in navigator)) {
      throw new Error('Bluetooth API not supported');
    }
    return await (navigator as any).bluetooth.requestDevice(options);
  }

  /** @returns {Promise<void>} @throws {Error} When Fullscreen API not supported. */
  async requestFullscreen(): Promise<void> {
    if (typeof document !== 'undefined' && document.documentElement.requestFullscreen) {
      await document.documentElement.requestFullscreen();
    } else {
      throw new Error('Fullscreen API not supported');
    }
  }

  /** @returns {Promise<boolean>} Whether persistent storage was granted. */
  async requestPersistentStorage(): Promise<boolean> {
    if (typeof navigator !== 'undefined' && 'storage' in navigator && 'persist' in navigator.storage) {
      return await navigator.storage.persist();
    }
    return false;
  }

  /** @returns {boolean} Whether File System Access (showDirectoryPicker) is supported. */
  isFileSystemAccessSupported(): boolean {
    return typeof window !== 'undefined' && 'showDirectoryPicker' in window;
  }

  /** @returns {Promise<boolean>} Whether Bluetooth is available. */
  async isBluetoothAvailable(): Promise<boolean> {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }

  // === PLATFORM-SPECIFIC STUBS (must be overridden by platforms) ===
  
  // Desktop operations (implemented in desktop.ts)
  async selectFolder(): Promise<string | null> {
    throw new Error('selectFolder not supported on this platform');
  }

  async openFile(_path: string): Promise<void> {
    throw new Error('openFile not supported on this platform');
  }

  async showInFolder(_path: string): Promise<void> {
    throw new Error('showInFolder not supported on this platform');
  }

  async showSaveDialog(_options?: any): Promise<string | null> {
    throw new Error('showSaveDialog not supported on this platform');
  }

  async setAutoStart(_enabled: boolean): Promise<void> {
    throw new Error('setAutoStart not supported on this platform');
  }

  async isAutoStartEnabled(): Promise<boolean> {
    throw new Error('isAutoStartEnabled not supported on this platform');
  }

  async getBluetoothDevices(): Promise<any[]> {
    throw new Error('getBluetoothDevices not supported on this platform');
  }

  // Mobile operations (implemented in mobile.ts)
  async requestPermissions(_permissions: string[]): Promise<Record<string, boolean>> {
    throw new Error('requestPermissions not supported on this platform');
  }

  async getBatteryLevel(): Promise<number> {
    throw new Error('getBatteryLevel not supported on this platform');
  }

  async isCharging(): Promise<boolean> {
    throw new Error('isCharging not supported on this platform');
  }

  // Node operations (implemented in node.ts)
  async readFile(_path: string): Promise<string> {
    throw new Error('readFile not supported on this platform');
  }

  async writeFile(_path: string, _content: string): Promise<void> {
    throw new Error('writeFile not supported on this platform');
  }

  async exists(_path: string): Promise<boolean> {
    throw new Error('exists not supported on this platform');
  }

  async getProcessInfo(): Promise<any> {
    throw new Error('getProcessInfo not supported on this platform');
  }

  async getSystemInfo(): Promise<any> {
    throw new Error('getSystemInfo not supported on this platform');
  }

  /**
   * Reconfigure the AI inferer (used by subclasses).
   * @param {*} config - New AI config.
   */
  protected reconfigureAI(config: any): void {
    this.ai = createAIInferer(config);
  }
}
