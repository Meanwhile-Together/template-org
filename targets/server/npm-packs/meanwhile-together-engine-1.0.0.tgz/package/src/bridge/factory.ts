/**
 * @fileoverview Bridge Factory - Creates platform-specific bridges (web, desktop, mobile, node).
 * Used in both browser and Node.js; do not import server-only modules here. AI config via config.ai in client.
 */

import type {
  BridgeImpl,
  PlatformType,
  BrowserBridge,
  DesktopBridge,
  MobileBridge,
  NodeBridge,
  DatabaseServiceConfig
} from '@meanwhile-together/shared';
import { 
  BrowserBridgeImpl 
} from './platforms/browser';
import { 
  DesktopBridgeImpl 
} from './platforms/desktop';
import { 
  MobileBridgeImpl 
} from './platforms/mobile';

// Default AI config for client environments (local inference)
const DEFAULT_CLIENT_AI_CONFIG = {
  inferenceMode: 'local' as const,
  localConfig: {
    allowedModels: ['Xenova/*', 'openai/*'],
    usePersistentStorage: true,
    enableWebGL: true,
    enableWebWorkers: true
  },
  enableLogging: false
};

/**
 * Configuration for BridgeFactory when creating a bridge.
 * @typedef {Object} BridgeFactoryConfig
 * @property {PlatformType} [platform] - Override platform (usually from createBridge(platform)).
 * @property {boolean} [enableLogging] - Enable logging.
 * @property {*} [ai] - AI configuration for the bridge (required in browser; optional in Node).
 * @property {DatabaseServiceConfig} [db] - Database config (Node platform only).
 */
export interface BridgeFactoryConfig {
  platform?: PlatformType;
  enableLogging?: boolean;
  ai?: any;
  db?: DatabaseServiceConfig;
}


/**
 * Factory for creating platform-specific bridge implementations.
 */
export class BridgeFactory {
  private static nodeBridgeCtor: (new (aiConfig?: any, dbConfig?: DatabaseServiceConfig) => NodeBridge) | null = null;

  private static resolveNodeBridgeCtor(): new (aiConfig?: any, dbConfig?: DatabaseServiceConfig) => NodeBridge {
    if (!this.nodeBridgeCtor) {
      // Keep Node bridge out of browser bundles; only resolve when explicitly requested.
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('./platforms/node');
      this.nodeBridgeCtor = mod.NodeBridgeImpl as new (aiConfig?: any, dbConfig?: DatabaseServiceConfig) => NodeBridge;
    }
    return this.nodeBridgeCtor;
  }

  /**
   * Create a platform bridge for the specified platform.
   * @param {PlatformType} platform - 'web' | 'desktop' | 'mobile' | 'node'.
   * @param {BridgeFactoryConfig} [config={}] - Optional config (ai, db, enableLogging).
   * @returns {BridgeImpl} Platform-specific bridge.
   * @throws {Error} When platform is unsupported.
   */
  static createBridge(platform: 'web', config?: BridgeFactoryConfig): BrowserBridge;
  static createBridge(platform: 'desktop', config?: BridgeFactoryConfig): DesktopBridge;
  static createBridge(platform: 'mobile', config?: BridgeFactoryConfig): MobileBridge;
  static createBridge(platform: 'node', config?: BridgeFactoryConfig): NodeBridge;
  static createBridge<P extends PlatformType>(platform: P, config: BridgeFactoryConfig = {}):
    P extends 'web' ? BrowserBridge :
    P extends 'desktop' ? DesktopBridge :
    P extends 'mobile' ? MobileBridge :
    P extends 'node' ? NodeBridge : BridgeImpl {
    // Get AI config - must be provided for browser environments
    // For Node.js, can fallback to loading from config files synchronously
    let aiConfig = config.ai;
    
    if (!aiConfig) {
      // For browser platforms without config, use default local inference
      if (platform === 'web' || platform === 'mobile' || platform === 'desktop') {
        aiConfig = DEFAULT_CLIENT_AI_CONFIG;
      } else {
        // Node.js: load synchronously (this path only runs in Node.js)
        try {
          // Dynamic require to avoid bundling server-config in client builds
          // eslint-disable-next-line @typescript-eslint/no-var-requires
          const serverConfigPath = '@meanwhile-together/shared/server-config';
          const { getAIConfigForPlatform } = require(serverConfigPath);
          aiConfig = getAIConfigForPlatform(platform);
        } catch {
          aiConfig = DEFAULT_CLIENT_AI_CONFIG;
        }
      }
    }
    
    switch (platform) {
      case 'web':
        return new BrowserBridgeImpl(aiConfig) as any;
      case 'desktop':
        return new DesktopBridgeImpl(aiConfig) as any;
      case 'mobile':
        return new MobileBridgeImpl(aiConfig) as any;
      case 'node': {
        const NodeBridgeCtor = this.resolveNodeBridgeCtor();
        return new NodeBridgeCtor(aiConfig, config.db) as any;
      }
      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }
  }

  /**
   * Auto-detect platform and create the appropriate bridge.
   * @param {BridgeFactoryConfig} [config={}] - Optional config.
   * @returns {BridgeImpl}
   */
  static createAutoBridge(config: BridgeFactoryConfig = {}): BridgeImpl {
    const platform = this.detectPlatform();
    // Cast to satisfy overloads when platform is a union type
    return this.createBridge(platform as any, config) as BridgeImpl;
  }

  /**
   * Detect the current platform (node, mobile, desktop, or web).
   * @returns {PlatformType}
   */
  static detectPlatform(): PlatformType {
    // Check for Node.js environment
    if (typeof process !== 'undefined' && process.versions && process.versions.node) {
      return 'node';
    }

    // Check for mobile
    if (typeof window !== 'undefined') {
      const userAgent = navigator.userAgent.toLowerCase();
      if (/android|iphone|ipad|ipod|blackberry|windows phone/.test(userAgent)) {
        return 'mobile';
      }
    }

    // Check for desktop (Electron, etc.)
    if (typeof window !== 'undefined' && (window as any).electronAPI) {
      return 'desktop';
    }

    // Default to web
    return 'web';
  }

  /**
   * Check if a platform is supported.
   * @param {PlatformType} platform - Platform to check.
   * @returns {boolean}
   */
  static isPlatformSupported(platform: PlatformType): boolean {
    return ['web', 'desktop', 'mobile', 'node'].includes(platform);
  }

  /**
   * Get list of available platform types.
   * @returns {PlatformType[]}
   */
  static getAvailablePlatforms(): PlatformType[] {
    return ['web', 'desktop', 'mobile', 'node'];
  }
}
