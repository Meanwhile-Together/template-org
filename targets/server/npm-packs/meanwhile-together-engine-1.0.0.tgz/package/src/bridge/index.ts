/**
 * @fileoverview Bridge module - Platform bridge interfaces, base implementation, platform impls, and factory.
 */
export * from './interface';

// Base platform bridge implementation
export * from './bridge';

// Platform bridge implementations
export * from './platforms/browser';
export * from './platforms/desktop';
export * from './platforms/mobile';

// Platform bridge factory
export * from './factory';

