/**
 * @fileoverview Platform Bridge Interface - Re-exports bridge-related types from @meanwhile-together/shared.
 * No local types; all BridgeImpl, PlatformType, etc. come from shared.
 */
export * from '@meanwhile-together/shared';
