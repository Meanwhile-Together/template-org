/**
 * @fileoverview Session store - key → { sessionId, updatedAt, modelOverride?, history? }. Persists to disk in Node when stateDir set.
 */
import type { SessionState } from '@meanwhile-together/shared';

/**
 * Options for SessionStore.
 * @typedef {Object} SessionStoreOptions
 * @property {string} [stateDir] - Directory for persisted state (e.g. ./.state). Omit for in-memory only.
 */
export interface SessionStoreOptions {
  stateDir?: string;
}

function isNode(): boolean {
  return typeof process !== 'undefined' && process.versions?.node != null;
}

/** Simple stable hash for session key → filename (no crypto deps). */
function hashKey(key: string): string {
  let h = 0;
  for (let i = 0; i < key.length; i++) {
    const c = key.charCodeAt(i);
    h = (h << 5) - h + c;
    h = h & h;
  }
  return Math.abs(h).toString(36);
}

/**
 * Session store: in-memory map with optional disk persistence (Node, stateDir).
 */
export class SessionStore {
  private memory: Map<string, SessionState> = new Map();
  private readonly stateDir?: string;

  /**
   * @param {SessionStoreOptions} [options={}] - stateDir for persistence.
   */
  constructor(options: SessionStoreOptions = {}) {
    this.stateDir = options.stateDir;
    if (this.stateDir && isNode()) {
      this.loadFromDisk();
    }
  }

  /**
   * @param {string} key - Session key.
   * @returns {SessionState | undefined}
   */
  get(key: string): SessionState | undefined {
    return this.memory.get(key);
  }

  /**
   * @param {string} key - Session key.
   * @param {SessionState} state - State to store.
   */
  set(key: string, state: SessionState): void {
    const normalized: SessionState = {
      sessionId: state.sessionId,
      updatedAt: state.updatedAt ?? Date.now(),
      modelOverride: state.modelOverride,
      history: state.history,
      presence: state.presence,
    };
    this.memory.set(key, normalized);
    if (this.stateDir && isNode()) {
      this.persistKey(key);
    }
  }

  /**
   * @param {string} key - Session key.
   * @returns {boolean} Whether the key was present and removed.
   */
  delete(key: string): boolean {
    const had = this.memory.delete(key);
    if (had && this.stateDir && isNode()) {
      this.deleteKeyFile(key);
    }
    return had;
  }

  markJoin(key: string): SessionState {
    const now = Date.now();
    const current = this.memory.get(key) ?? { sessionId: key, updatedAt: now };
    const next: SessionState = {
      ...current,
      updatedAt: now,
      presence: {
        ...current.presence,
        joinedAt: current.presence?.joinedAt ?? now,
        lastHeartbeatAt: now,
      },
    };
    this.set(key, next);
    return next;
  }

  markHeartbeat(key: string): SessionState {
    const now = Date.now();
    const current = this.memory.get(key) ?? { sessionId: key, updatedAt: now };
    const next: SessionState = {
      ...current,
      updatedAt: now,
      presence: {
        ...current.presence,
        joinedAt: current.presence?.joinedAt ?? now,
        lastHeartbeatAt: now,
      },
    };
    this.set(key, next);
    return next;
  }

  markLeave(key: string): SessionState {
    const now = Date.now();
    const current = this.memory.get(key) ?? { sessionId: key, updatedAt: now };
    const next: SessionState = {
      ...current,
      updatedAt: now,
      presence: {
        ...current.presence,
        lastLeftAt: now,
      },
    };
    this.set(key, next);
    return next;
  }

  getPresence(key: string): SessionState['presence'] | undefined {
    return this.memory.get(key)?.presence;
  }

  private getKeyPath(key: string): string {
    if (!this.stateDir) {
      throw new Error('stateDir is required for persistence');
    }
    const path = require('path');
    return path.join(this.stateDir, `session_${hashKey(key)}.json`);
  }

  private loadFromDisk(): void {
    const fs = require('fs');
    const path = require('path');
    if (!this.stateDir) return;
    try {
      if (!fs.existsSync(this.stateDir)) {
        fs.mkdirSync(this.stateDir, { recursive: true });
        return;
      }
      const files = fs.readdirSync(this.stateDir);
      for (const file of files) {
        if (!file.startsWith('session_') || !file.endsWith('.json')) continue;
        const fullPath = path.join(this.stateDir, file);
        try {
          const raw = fs.readFileSync(fullPath, 'utf8');
          const data = JSON.parse(raw) as { key: string; state: SessionState };
          if (data.key && data.state?.sessionId != null && data.state?.updatedAt != null) {
            this.memory.set(data.key, data.state);
          }
        } catch {
          // Skip invalid files
        }
      }
    } catch {
      // Ignore read errors; run in-memory only
    }
  }

  private persistKey(key: string): void {
    const fs = require('fs');
    const state = this.memory.get(key);
    if (!state) return;
    try {
      if (!fs.existsSync(this.stateDir!)) {
        fs.mkdirSync(this.stateDir!, { recursive: true });
      }
      const filePath = this.getKeyPath(key);
      const data = { key, state };
      fs.writeFileSync(filePath, JSON.stringify(data, null, 0), 'utf8');
    } catch {
      // Ignore write errors
    }
  }

  private deleteKeyFile(key: string): void {
    try {
      const fs = require('fs');
      const filePath = this.getKeyPath(key);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch {
      // Ignore
    }
  }
}
