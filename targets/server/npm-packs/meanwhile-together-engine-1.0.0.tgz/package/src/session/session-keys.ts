/**
 * @fileoverview Session key format `agent:<agentId>:<rest>`. Helpers for parsing and building (used by bridge.ai.runAgent).
 */
import type { ParsedSessionKey } from '@meanwhile-together/shared';

const PREFIX = 'agent:';

/**
 * Parse a session key into agentId and rest.
 * @param {string} sessionKey - Key in form agent:agentId or agent:agentId:rest.
 * @returns {ParsedSessionKey | null} Parsed result or null if invalid.
 */
export function parseSessionKey(sessionKey: string): ParsedSessionKey | null {
  if (!sessionKey || !sessionKey.startsWith(PREFIX)) {
    return null;
  }
  const after = sessionKey.slice(PREFIX.length);
  const firstColon = after.indexOf(':');
  if (firstColon === -1) {
    return { agentId: after, rest: '' };
  }
  return {
    agentId: after.slice(0, firstColon),
    rest: after.slice(firstColon + 1),
  };
}

/**
 * Build a session key from agentId and optional rest.
 * @param {string} agentId - Agent identifier.
 * @param {string} [rest=''] - Optional suffix after second colon.
 * @returns {string} agent:agentId or agent:agentId:rest.
 * @throws {Error} When agentId is empty.
 */
export function buildSessionKey(agentId: string, rest: string = ''): string {
  if (!agentId) {
    throw new Error('agentId is required');
  }
  return rest ? `${PREFIX}${agentId}:${rest}` : `${PREFIX}${agentId}`;
}

/**
 * Check if a string is a valid session key (starts with agent:).
 * @param {string} key - String to check.
 * @returns {boolean}
 */
export function isSessionKey(key: string): boolean {
  return typeof key === 'string' && key.startsWith(PREFIX);
}
