/**
 * @fileoverview Database module - Unified, app, backend, stub, and legacy database services.
 */
export { 
  UnifiedDatabaseServiceImpl,
  createUnifiedDatabaseService,
  createAppOnlyDatabaseService
} from './unified-database-service';

// App and backend database services
export { 
  AppDatabaseServiceImpl,
  createAppDatabaseService
} from './app-database-service';

export { 
  BackendDatabaseServiceImpl,
  createBackendDatabaseService,
  // Legacy aliases
  AdminDatabaseServiceImpl,
  createAdminDatabaseService
} from './backend-database-service';

// Legacy (for backward compatibility)
export { DatabaseServiceImpl, createDatabaseService } from './database-service';

// Stub for non-Node platforms
export { StubDatabaseService, createStubDatabaseService } from './stub-database-service';

export type { DatabaseService, AppDatabaseService, BackendDatabaseService, AdminDatabaseService } from '@meanwhile-together/shared';
