/**
 * @fileoverview Stub database service for platforms without DB access. All operations throw or return safe defaults.
 */

import type { DatabaseService, AppDatabaseService, AdminDatabaseService, ModelQuery } from '@meanwhile-together/shared';
import { DatabaseError } from '@meanwhile-together/shared/database-errors';

/**
 * Create a stub ModelQuery that throws on every call.
 * @param {string} modelName - Model name (for error message).
 * @returns {ModelQuery}
 */
function createStubModel(modelName: string): ModelQuery {
  const stub = async () => {
    throw new DatabaseError(
      `Database access is not available on this platform. Database operations are only supported on the Node.js (server) platform.`,
      'PLATFORM_NOT_SUPPORTED',
      { model: modelName, platform: typeof window !== 'undefined' ? 'browser' : 'unknown' }
    );
  };

  return {
    findUnique: stub,
    findUniqueOrThrow: stub,
    findFirst: stub,
    findFirstOrThrow: stub,
    findMany: stub,
    create: stub,
    createMany: stub,
    update: stub,
    updateMany: stub,
    upsert: stub,
    delete: stub,
    deleteMany: stub,
    count: stub,
    aggregate: stub,
    groupBy: stub
  } as ModelQuery;
}

/** Stub app database: user/conversation stubs, all transactions/raw/connect throw. */
class StubAppDatabaseService implements AppDatabaseService {
  readonly user: ModelQuery;
  readonly conversation: ModelQuery;

  constructor() {
    this.user = createStubModel('user');
    this.conversation = createStubModel('conversation');
  }

  async $transaction<T>(_callbackOrQueries: any): Promise<T | T[]> {
    throw new DatabaseError('Database transactions are not available on this platform', 'PLATFORM_NOT_SUPPORTED');
  }

  async $connect(): Promise<void> {
    throw new DatabaseError('Database connection is not available on this platform', 'PLATFORM_NOT_SUPPORTED');
  }

  async $disconnect(): Promise<void> {
    // No-op
  }

  $on(_event: any, _callback: any): void {
    // No-op
  }

  async $queryRaw<T = any>(_query: string, ..._values: any[]): Promise<T[]> {
    throw new DatabaseError('Raw queries are not available on this platform', 'PLATFORM_NOT_SUPPORTED');
  }

  async $executeRaw(_query: string, ..._values: any[]): Promise<number> {
    throw new DatabaseError('Raw execute is not available on this platform', 'PLATFORM_NOT_SUPPORTED');
  }

  $extends(_extension: any): AppDatabaseService {
    return this;
  }

  async isConnected(): Promise<boolean> {
    return false;
  }

  async getSchema(): Promise<Record<string, any>> {
    return { message: 'Database is not available on this platform', available: false };
  }
}

/**
 * Stub database service: app stub only; all operations throw or no-op. For non-Node platforms.
 */
export class StubDatabaseService implements DatabaseService {
  readonly app: AppDatabaseService;
  readonly admin?: AdminDatabaseService;
  readonly user: ModelQuery;
  readonly conversation: ModelQuery;

  constructor() {
    const appService = new StubAppDatabaseService();
    this.app = appService;
    this.user = appService.user;
    this.conversation = appService.conversation;
    // Admin is undefined for stub (not available on non-Node platforms)
  }

}

/**
 * Create a stub database service (for browser/desktop/mobile).
 * @returns {DatabaseService}
 */
export function createStubDatabaseService(): DatabaseService {
  return new StubDatabaseService();
}
