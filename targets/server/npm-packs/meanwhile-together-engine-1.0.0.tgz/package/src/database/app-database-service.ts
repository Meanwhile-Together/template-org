/**
 * @fileoverview App database service - Wraps app-schema Prisma client (user, conversation, etc.).
 */

import type { AppDatabaseService, ModelQuery } from '@meanwhile-together/shared';
import {
  DatabaseError,
  DatabaseConnectionError,
  DatabaseQueryError,
  DatabaseValidationError
} from '@meanwhile-together/shared/database-errors';

// Dynamic import to avoid circular dependencies
type PrismaClient = any;

/**
 * Create ModelQuery for a Prisma model. Wraps findUnique, findMany, create, update, delete, etc. with typed errors.
 * @param {PrismaClient} prismaClient - Prisma client.
 * @param {string} modelName - Model name.
 * @returns {ModelQuery}
 */
function createModelQuery(prismaClient: PrismaClient, modelName: string): ModelQuery {
  const model = (prismaClient as any)[modelName];
  if (!model) {
    throw new DatabaseError(`Model '${modelName}' not found in schema`);
  }

  return {
    async findUnique(options: any) {
      try {
        return await model.findUnique(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to find unique ${modelName}`, { error: error.message, options });
      }
    },

    async findUniqueOrThrow(options: any) {
      try {
        return await model.findUniqueOrThrow(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to find unique ${modelName} (or throw)`, { error: error.message, options });
      }
    },

    async findFirst(options?: any) {
      try {
        return await model.findFirst(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to find first ${modelName}`, { error: error.message, options });
      }
    },

    async findFirstOrThrow(options?: any) {
      try {
        return await model.findFirstOrThrow(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to find first ${modelName} (or throw)`, { error: error.message, options });
      }
    },

    async findMany(options?: any) {
      try {
        return await model.findMany(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to find many ${modelName}`, { error: error.message, options });
      }
    },

    async create(options: any) {
      try {
        return await model.create(options);
      } catch (error: any) {
        if (error.code === 'P2002') {
          throw new DatabaseValidationError(`Unique constraint violation on ${modelName}`, { error: error.message, options });
        }
        throw new DatabaseQueryError(`Failed to create ${modelName}`, { error: error.message, options });
      }
    },

    async createMany(options: any) {
      try {
        return await model.createMany(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to create many ${modelName}`, { error: error.message, options });
      }
    },

    async update(options: any) {
      try {
        return await model.update(options);
      } catch (error: any) {
        if (error.code === 'P2025') {
          throw new DatabaseQueryError(`Record not found for update in ${modelName}`, { error: error.message, options });
        }
        throw new DatabaseQueryError(`Failed to update ${modelName}`, { error: error.message, options });
      }
    },

    async updateMany(options: any) {
      try {
        return await model.updateMany(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to update many ${modelName}`, { error: error.message, options });
      }
    },

    async upsert(options: any) {
      try {
        return await model.upsert(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to upsert ${modelName}`, { error: error.message, options });
      }
    },

    async delete(options: any) {
      try {
        return await model.delete(options);
      } catch (error: any) {
        if (error.code === 'P2025') {
          throw new DatabaseQueryError(`Record not found for delete in ${modelName}`, { error: error.message, options });
        }
        throw new DatabaseQueryError(`Failed to delete ${modelName}`, { error: error.message, options });
      }
    },

    async deleteMany(options: any) {
      try {
        return await model.deleteMany(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to delete many ${modelName}`, { error: error.message, options });
      }
    },

    async count(options?: any) {
      try {
        return await model.count(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to count ${modelName}`, { error: error.message, options });
      }
    },

    async aggregate(options?: any) {
      try {
        return await model.aggregate(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to aggregate ${modelName}`, { error: error.message, options });
      }
    },

    async groupBy(options: any) {
      try {
        return await model.groupBy(options);
      } catch (error: any) {
        throw new DatabaseQueryError(`Failed to group by ${modelName}`, { error: error.message, options });
      }
    }
  };
}

/**
 * App database service: app schema only (user, conversation); transactions, raw, connect, getSchema.
 */
export class AppDatabaseServiceImpl implements AppDatabaseService {
  private prismaClient: PrismaClient;
  private _models: Map<string, ModelQuery> = new Map();

  /** @param {PrismaClient} prismaClient - App schema Prisma client. */
  constructor(prismaClient: PrismaClient) {
    this.prismaClient = prismaClient;
    this.initializeModels();
  }

  private initializeModels(): void {
    // Get all model names from Prisma client
    const modelNames = Object.getOwnPropertyNames(this.prismaClient)
      .filter(name => !name.startsWith('$') && typeof (this.prismaClient as any)[name] === 'object');

    // Create model query wrappers
    for (const modelName of modelNames) {
      this._models.set(modelName, createModelQuery(this.prismaClient, modelName));
    }
  }

  // Model accessors
  get user(): ModelQuery {
    return this._models.get('user') || this.createStubModel('user');
  }

  get conversation(): ModelQuery {
    return this._models.get('conversation') || this.createStubModel('conversation');
  }

  private createStubModel(name: string): ModelQuery {
    const stub = async () => {
      throw new DatabaseError(`Model '${name}' is not available in the app schema`);
    };
    return {
      findUnique: stub,
      findUniqueOrThrow: stub,
      findFirst: stub,
      findFirstOrThrow: stub,
      findMany: stub,
      create: stub,
      createMany: stub,
      update: stub,
      updateMany: stub,
      upsert: stub,
      delete: stub,
      deleteMany: stub,
      count: stub,
      aggregate: stub,
      groupBy: stub
    } as ModelQuery;
  }

  // Transaction support
  async $transaction<T>(callbackOrQueries: ((tx: AppDatabaseService) => Promise<T>) | Promise<T>[]): Promise<T | T[]> {
    try {
      if (Array.isArray(callbackOrQueries)) {
        return await this.prismaClient.$transaction(callbackOrQueries);
      } else {
        return await this.prismaClient.$transaction(async (tx: PrismaClient) => {
          const txService = new AppDatabaseServiceImpl(tx);
          return await callbackOrQueries(txService);
        });
      }
    } catch (error: any) {
      throw new DatabaseQueryError('Transaction failed', { error: error.message });
    }
  }

  // Connection management
  async $connect(): Promise<void> {
    try {
      await this.prismaClient.$connect();
    } catch (error: any) {
      throw new DatabaseConnectionError('Failed to connect to database', { error: error.message });
    }
  }

  async $disconnect(): Promise<void> {
    try {
      await this.prismaClient.$disconnect();
    } catch (error: any) {
      throw new DatabaseConnectionError('Failed to disconnect from database', { error: error.message });
    }
  }

  $on(event: 'query' | 'info' | 'warn' | 'error', callback: (e: any) => void): void {
    this.prismaClient.$on(event, callback);
  }

  // Raw queries
  async $queryRaw<T = any>(query: string, ...values: any[]): Promise<T[]> {
    try {
      return await this.prismaClient.$queryRaw(query, ...values);
    } catch (error: any) {
      throw new DatabaseQueryError('Raw query failed', { error: error.message, query });
    }
  }

  async $executeRaw(query: string, ...values: any[]): Promise<number> {
    try {
      return await this.prismaClient.$executeRaw(query, ...values);
    } catch (error: any) {
      throw new DatabaseQueryError('Raw execute failed', { error: error.message, query });
    }
  }

  // Extensions
  $extends(extension: any): AppDatabaseService {
    const extendedClient = this.prismaClient.$extends(extension);
    return new AppDatabaseServiceImpl(extendedClient);
  }

  // Health check
  async isConnected(): Promise<boolean> {
    try {
      await this.prismaClient.$queryRaw`SELECT 1`;
      return true;
    } catch {
      return false;
    }
  }

  // Schema introspection
  async getSchema(): Promise<Record<string, any>> {
    try {
      const schema: Record<string, any> = {};
      for (const [name, model] of this._models.entries()) {
        schema[name] = {
          name,
          available: true,
          methods: Object.keys(model)
        };
      }
      return schema;
    } catch (error: any) {
      throw new DatabaseError('Failed to get schema', undefined, { error: error.message });
    }
  }
}

/**
 * Create an app database service from an app-schema Prisma client.
 * @param {PrismaClient} prismaClient - App Prisma client.
 * @returns {AppDatabaseService}
 */
export function createAppDatabaseService(prismaClient: PrismaClient): AppDatabaseService {
  return new AppDatabaseServiceImpl(prismaClient);
}
