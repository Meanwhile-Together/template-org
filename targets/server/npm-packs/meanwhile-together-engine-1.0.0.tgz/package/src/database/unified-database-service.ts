/**
 * @fileoverview Unified database service - App + optional backend schema with access control (allowBackendAccess, context).
 */

import type {
  DatabaseService,
  DatabaseServiceConfig,
  AppDatabaseService,
  BackendDatabaseService,
  ModelQuery
} from '@meanwhile-together/shared';
import { DatabaseError } from '@meanwhile-together/shared/database-errors';
import { createAppDatabaseService } from './app-database-service';
import { createBackendDatabaseService } from './backend-database-service';

// Dynamic import to avoid circular dependencies
type PrismaClient = any;

/**
 * Check if backend DB access is allowed (config flags, unified server backend context, env).
 * @param {DatabaseServiceConfig} [config] - Service config.
 * @returns {boolean}
 */
function isBackendAccessAllowed(config?: DatabaseServiceConfig): boolean {
  // Explicit allow flag (new or legacy)
  if (config?.allowBackendAccess === true || config?.allowAdminAccess === true) {
    return true;
  }

  // Check if we're in backend context (unified server running with admin payload)
  if (typeof require !== 'undefined') {
    try {
      const mainModule = require.main;
      if (mainModule) {
        const filename = mainModule.filename || '';
        // Check if running from unified server in backend mode (targets/server) or backend target build
        if (filename.includes('targets/server') || filename.includes('backend/server') ||
            filename.includes('admin-server') || filename.includes('admin/server')) {  // Legacy paths, deprecated
          return true;
        }
        // Check if running from server (which can have backend access)
        if (filename.includes('targets/server') || filename.includes('server/src')) {
          // Server can access backend if explicitly configured
          return config?.schema === 'both' || config?.schema === 'backend';
        }
      }
    } catch {
      // If we can't determine, default to false for safety
    }
  }

  // Check environment variable (new or legacy)
  if (process.env.ALLOW_BACKEND_DB_ACCESS === 'true' || process.env.ALLOW_ADMIN_DB_ACCESS === 'true') {
    return true;
  }

  // Check if schema is explicitly set to 'both' or 'backend'
  if (config?.schema === 'both' || config?.schema === 'backend') {
    // Still need to verify we're in the right context
    // This is a safety check - the explicit flag should be used
    return false; // Default to false unless explicitly allowed
  }

  return false;
}

/**
 * Unified database service: app always; backend only when allowed and client provided.
 */
export class UnifiedDatabaseServiceImpl implements DatabaseService {
  private _app: AppDatabaseService;
  private _backend?: BackendDatabaseService;
  private backendAccessAllowed: boolean;

  /**
   * @param {PrismaClient} appClient - App schema Prisma client.
   * @param {PrismaClient | null} backendClient - Backend schema client (optional).
   * @param {DatabaseServiceConfig} [config] - allowBackendAccess, schema, etc.
   */
  constructor(
    appClient: PrismaClient,
    backendClient: PrismaClient | null,
    config?: DatabaseServiceConfig
  ) {
    // Create app database service (always available)
    this._app = createAppDatabaseService(appClient);

    // Check if backend access is allowed
    this.backendAccessAllowed = isBackendAccessAllowed(config);

    // Create backend database service if access is allowed and client is provided
    if (this.backendAccessAllowed && backendClient) {
      this._backend = createBackendDatabaseService(backendClient);
    } else if (backendClient && !this.backendAccessAllowed) {
      console.warn(
        '[DatabaseService] Backend database client provided but access is not allowed. ' +
        'Backend schema will not be available. ' +
        'Set allowBackendAccess: true in config or ensure you are running in unified server backend context.'
      );
    }
  }

  // App schema access (always available)
  get app(): AppDatabaseService {
    return this._app;
  }

  // Backend schema access (only if allowed)
  get backend(): BackendDatabaseService | undefined {
    if (!this.backendAccessAllowed) {
      throw new DatabaseError(
        'Backend database access is not allowed. ' +
        'Backend schema access is restricted to backend-server and server contexts. ' +
        'Set allowBackendAccess: true in config if you need backend access.',
        'BACKEND_ACCESS_DENIED'
      );
    }
    if (!this._backend) {
      throw new DatabaseError(
        'Backend database service is not initialized. ' +
        'Ensure backend Prisma client is available.',
        'BACKEND_NOT_INITIALIZED'
      );
    }
    return this._backend;
  }

  /** @deprecated Use backend instead */
  get admin(): BackendDatabaseService | undefined {
    return this.backend;
  }

  // Convenience accessors for app schema (backward compatibility)
  get user(): ModelQuery {
    return this._app.user;
  }

  get conversation(): ModelQuery {
    return this._app.conversation;
  }
}

/**
 * Create unified database service with app and optional backend access.
 * @param {PrismaClient} appClient - App Prisma client.
 * @param {PrismaClient | null} backendClient - Backend Prisma client (optional).
 * @param {DatabaseServiceConfig} [config] - Access control and schema options.
 * @returns {DatabaseService}
 */
export function createUnifiedDatabaseService(
  appClient: PrismaClient,
  backendClient: PrismaClient | null,
  config?: DatabaseServiceConfig
): DatabaseService {
  return new UnifiedDatabaseServiceImpl(appClient, backendClient, config);
}

/**
 * Create database service with app schema only (no backend).
 * @param {PrismaClient} appClient - App Prisma client.
 * @param {DatabaseServiceConfig} [config] - Optional config.
 * @returns {DatabaseService}
 */
export function createAppOnlyDatabaseService(
  appClient: PrismaClient,
  config?: DatabaseServiceConfig
): DatabaseService {
  return new UnifiedDatabaseServiceImpl(appClient, null, config);
}
