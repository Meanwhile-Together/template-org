/**
 * @fileoverview AI providers - Custom inferrers (Google; OpenAI/Anthropic stubbed).
 */
export { GoogleInferer } from './google-inferer';

