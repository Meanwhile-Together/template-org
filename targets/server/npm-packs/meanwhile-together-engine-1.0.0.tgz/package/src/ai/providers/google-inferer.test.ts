import { GoogleInferer } from './google-inferer';

const generateContentMock = jest.fn(async () => ({
  response: { text: () => 'fallback-text' },
}));
const generateContentStreamMock = jest.fn(async () => ({
  stream: (async function* () {
    yield { text: () => 'chunk-1 ' };
    yield { text: () => 'chunk-2' };
  })(),
}));
const sendMessageMock = jest.fn(async () => ({
  response: { text: () => 'chat-fallback' },
}));
const startChatMock = jest.fn(() => ({ sendMessage: sendMessageMock }));
const getGenerativeModelMock = jest.fn(() => ({
  generateContent: generateContentMock,
  generateContentStream: generateContentStreamMock,
  startChat: startChatMock,
}));

jest.mock('@google/generative-ai', () => ({
  GoogleGenerativeAI: jest.fn().mockImplementation(() => ({
    getGenerativeModel: getGenerativeModelMock,
  })),
}));

describe('GoogleInferer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('chatCompletionStream returns async iterable chunks', async () => {
    const inferer = new GoogleInferer({ provider: { name: 'google', apiKey: 'test-key' } });
    const stream = await inferer.chatCompletionStream({
      model: 'google/gemini-2.0-flash',
      messages: [{ role: 'user', content: 'hello' }],
    });

    const chunks: string[] = [];
    for await (const chunk of stream) {
      chunks.push(chunk.choices?.[0]?.delta?.content ?? '');
    }

    expect(chunks).toEqual(['chunk-1 ', 'chunk-2']);
  });

  it('textGenerationStream falls back when stream API unavailable', async () => {
    generateContentStreamMock.mockResolvedValueOnce({ stream: null });
    generateContentMock.mockResolvedValueOnce({ response: { text: () => 'fallback-generated' } });
    const inferer = new GoogleInferer({ provider: { name: 'google', apiKey: 'test-key' } });
    const stream = await inferer.textGenerationStream({
      model: 'google/gemini-2.0-flash',
      inputs: 'Generate a short response',
    });

    const chunks: string[] = [];
    for await (const chunk of stream) {
      chunks.push(chunk.choices?.[0]?.delta?.content ?? '');
    }

    expect(chunks).toEqual(['fallback-generated']);
  });

  it('image methods return structured results', async () => {
    generateContentMock
      .mockResolvedValueOnce({ response: { text: () => 'cat, animal, pet' } })
      .mockResolvedValueOnce({ response: { text: () => 'A cat sitting on a couch.' } });
    const inferer = new GoogleInferer({ provider: { name: 'google', apiKey: 'test-key' } });
    const image = 'data:image/png;base64,ZmFrZQ==';

    const classification = await inferer.imageClassification({ image });
    const description = await inferer.imageToText({ image });

    expect(classification.labels).toContain('cat');
    expect(classification.generated_text).toContain('cat');
    expect(description.generated_text).toContain('cat');
  });

  it('chatCompletion includes structured output when schema matches', async () => {
    sendMessageMock.mockResolvedValueOnce({
      response: { text: () => '{"topic":"deploy","confidence":0.9}' },
    });
    const inferer = new GoogleInferer({ provider: { name: 'google', apiKey: 'test-key' } });
    const result = await inferer.chatCompletion({
      model: 'google/gemini-2.0-flash',
      messages: [{ role: 'user', content: 'summarize' }],
      responseSchema: {
        name: 'summary',
        validate: (value: unknown): value is { topic: string; confidence: number } => {
          const row = value as { topic?: unknown; confidence?: unknown };
          return typeof row?.topic === 'string' && typeof row?.confidence === 'number';
        },
      },
    });

    expect(result.choices[0].message.content).toContain('deploy');
    expect(result.structured).toEqual({ topic: 'deploy', confidence: 0.9 });
    expect(result.structuredError).toBeUndefined();
  });
});
