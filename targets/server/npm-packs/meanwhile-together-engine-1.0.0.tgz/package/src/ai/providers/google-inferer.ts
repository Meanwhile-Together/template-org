/**
 * @fileoverview Google AI inferer - Chat/text generation via Google Generative AI (Gemini). Implements AIInfererImpl.
 */
import { GoogleGenerativeAI } from '@google/generative-ai';
import type { AIInfererImpl, AIInfererConfig, AiInferenceCapabilities, RunAgentOptions, RunAgentResult } from '@meanwhile-together/shared';
import { parseSessionKey } from '../../session';
import { SessionStore } from '../../session';
import { parseStructuredOutput, type StructuredSchema } from '../structured-output';

/**
 * Google (Gemini) inferer: textGeneration, chatCompletion, runAgent; other methods throw not implemented.
 */
export class GoogleInferer implements AIInfererImpl {
  private client: GoogleGenerativeAI;
  private config: AIInfererConfig;

  /**
   * @param {AIInfererConfig} config - Must include provider.apiKey for Google.
   * @throws {Error} When provider.apiKey is missing.
   */
  constructor(config: AIInfererConfig) {
    if (!config.provider?.apiKey) {
      throw new Error('Google AI API key is required');
    }
    this.config = config;
    this.client = new GoogleGenerativeAI(config.provider.apiKey);
  }

  // Transform model name: google/xxx -> models/xxx for Google API
  private normalizeModelName(modelName: string): string {
    if (!modelName) return 'gemini-pro';
    // Replace google/ prefix with models/ prefix for Google API
    return modelName.replace(/^google\//, 'models/');
  }

  async textGeneration(args: any, _options?: any): Promise<any> {
    const googleModel = this.normalizeModelName(args.model);
    const model = this.client.getGenerativeModel({ model: googleModel });
    const result = await model.generateContent(args.inputs);
    return { generated_text: result.response.text() };
  }

  async chatCompletion(args: any, _options?: any): Promise<any> {
    const googleModel = this.normalizeModelName(args.model);
    const model = this.client.getGenerativeModel({ model: googleModel });
    const chat = model.startChat();
    const result = await chat.sendMessage(args.messages?.[args.messages.length - 1]?.content || '');
    const text = result.response.text();
    const responseSchema = args?.responseSchema as StructuredSchema<unknown> | undefined;
    const structured = responseSchema ? parseStructuredOutput(text, responseSchema) : null;
    return {
      choices: [{ message: { content: text } }],
      ...(structured?.ok ? { structured: structured.data } : {}),
      ...(structured && !structured.ok ? { structuredError: structured.error } : {}),
    };
  }

  private extractLastUserContent(messages: Array<{ role?: string; content?: unknown }> = []): string {
    for (let i = messages.length - 1; i >= 0; i -= 1) {
      const candidate = messages[i];
      if (candidate?.role === 'user' && typeof candidate?.content === 'string') {
        return candidate.content;
      }
    }
    const last = messages[messages.length - 1];
    return typeof last?.content === 'string' ? last.content : '';
  }

  private toInlineImageData(args: any): { mimeType: string; data: string } | null {
    const source = args?.image ?? args?.inputs?.image ?? args?.inputs ?? args;
    if (!source) return null;
    if (typeof source === 'string') {
      const dataUrl = source.match(/^data:(.+?);base64,(.+)$/);
      if (dataUrl) {
        return { mimeType: dataUrl[1], data: dataUrl[2] };
      }
      return { mimeType: args?.mimeType ?? 'image/jpeg', data: source };
    }
    if (typeof source === 'object' && typeof source.data === 'string') {
      return {
        mimeType: source.mimeType ?? source.mime_type ?? args?.mimeType ?? 'image/jpeg',
        data: source.data,
      };
    }
    return null;
  }

  private async *singleChunkStreamFromText(text: string): AsyncIterable<{ choices: Array<{ delta: { content: string } }> }> {
    yield { choices: [{ delta: { content: text } }] };
  }

  // Stub implementations for other methods (throw not implemented errors)
  async textClassification() { throw new Error('Not implemented for Google'); }
  async translation() { throw new Error('Not implemented for Google'); }
  async summarization() { throw new Error('Not implemented for Google'); }
  async questionAnswering() { throw new Error('Not implemented for Google'); }
  async fillMask() { throw new Error('Not implemented for Google'); }
  async sentenceSimilarity() { throw new Error('Not implemented for Google'); }
  async featureExtraction() { throw new Error('Not implemented for Google'); }
  async tokenClassification() { throw new Error('Not implemented for Google'); }
  async zeroShotClassification() { throw new Error('Not implemented for Google'); }
  async textToImage() { throw new Error('Not implemented for Google'); }
  async imageClassification(args: any, _options?: any): Promise<any> {
    const googleModel = this.normalizeModelName(args?.model ?? 'gemini-2.0-flash');
    const model = this.client.getGenerativeModel({ model: googleModel });
    const inlineData = this.toInlineImageData(args);
    const prompt = args?.prompt ?? 'Classify this image and return concise labels.';
    const contents = inlineData
      ? [{ text: prompt }, { inlineData }]
      : [{ text: `${prompt}\n\nNo image input was provided.` }];
    const result = await model.generateContent(contents);
    const text = result.response.text();
    return {
      labels: text
        .split(/[\n,]+/)
        .map((s: string) => s.trim())
        .filter(Boolean)
        .slice(0, 10),
      generated_text: text,
    };
  }
  async imageToText(args: any, _options?: any): Promise<any> {
    const googleModel = this.normalizeModelName(args?.model ?? 'gemini-2.0-flash');
    const model = this.client.getGenerativeModel({ model: googleModel });
    const inlineData = this.toInlineImageData(args);
    const prompt = args?.prompt ?? 'Describe this image.';
    const contents = inlineData
      ? [{ text: prompt }, { inlineData }]
      : [{ text: `${prompt}\n\nNo image input was provided.` }];
    const result = await model.generateContent(contents);
    return { generated_text: result.response.text() };
  }
  async automaticSpeechRecognition() { throw new Error('Not implemented for Google'); }
  async textToSpeech() { throw new Error('Not implemented for Google'); }
  async chatCompletionStream(args: any, _options?: any): Promise<AsyncIterable<{ choices: Array<{ delta: { content: string } }> }>> {
    const googleModel = this.normalizeModelName(args?.model);
    const model = this.client.getGenerativeModel({ model: googleModel });
    const prompt = this.extractLastUserContent(args?.messages);
    const streamFn = (model as any).generateContentStream;
    if (typeof streamFn === 'function') {
      const result = await streamFn.call(model, prompt);
      const stream = result?.stream;
      if (stream && Symbol.asyncIterator in stream) {
        return (async function* () {
          for await (const chunk of stream) {
            const text = typeof chunk?.text === 'function' ? chunk.text() : chunk?.text?.() ?? '';
            if (text) {
              yield { choices: [{ delta: { content: text } }] };
            }
          }
        })();
      }
    }
    const completion = await this.chatCompletion(args);
    const content = completion?.choices?.[0]?.message?.content ?? '';
    return this.singleChunkStreamFromText(content);
  }
  async textGenerationStream(args: any, _options?: any): Promise<AsyncIterable<{ choices: Array<{ delta: { content: string } }> }>> {
    const googleModel = this.normalizeModelName(args?.model);
    const model = this.client.getGenerativeModel({ model: googleModel });
    const prompt = args?.inputs ?? args?.prompt ?? '';
    const streamFn = (model as any).generateContentStream;
    if (typeof streamFn === 'function') {
      const result = await streamFn.call(model, prompt);
      const stream = result?.stream;
      if (stream && Symbol.asyncIterator in stream) {
        return (async function* () {
          for await (const chunk of stream) {
            const text = typeof chunk?.text === 'function' ? chunk.text() : chunk?.text?.() ?? '';
            if (text) {
              yield { choices: [{ delta: { content: text } }] };
            }
          }
        })();
      }
    }
    const generated = await this.textGeneration(args);
    const content = generated?.generated_text ?? '';
    return this.singleChunkStreamFromText(content);
  }

  async runAgent(opts: RunAgentOptions): Promise<RunAgentResult> {
    const parsed = parseSessionKey(opts.sessionKey);
    if (!parsed) throw new Error(`Invalid session key: ${opts.sessionKey}`);
    const store = new SessionStore({ stateDir: opts.stateDir });
    let state = store.get(opts.sessionKey);
    if (!state) {
      state = { sessionId: opts.sessionKey, updatedAt: Date.now(), history: [] };
      store.set(opts.sessionKey, state);
    }
    store.markJoin(opts.sessionKey);
    store.markHeartbeat(opts.sessionKey);
    const historyLimit = opts.historyLimit ?? 20;
    const history = (state.history ?? []).slice(-historyLimit);
    const messages = [...history, { role: 'user' as const, content: opts.prompt }];
    const model = opts.model ?? state.modelOverride ?? 'gemini-2.0-flash';
    const result = await this.chatCompletion({ model, messages }) as { choices?: Array<{ message?: { content?: string } }> };
    const content = result?.choices?.[0]?.message?.content ?? '';
    const newHistory: Array<{ role: 'user' | 'assistant' | 'system'; content: string }> = [...(state.history ?? []), { role: 'user', content: opts.prompt }, { role: 'assistant', content }];
    state.history = newHistory.slice(-(opts.historyLimit ?? 20));
    state.updatedAt = Date.now();
    store.set(opts.sessionKey, state);
    store.markHeartbeat(opts.sessionKey);
    return { payloads: [{ type: 'text', content }], meta: { model } };
  }
  
  async getCapabilities(): Promise<AiInferenceCapabilities> {
    return { cloud: true, local: false };
  }
  
  async isAvailable(): Promise<boolean> { return true; }
  async healthCheck(): Promise<any> {
    return { status: 'healthy', provider: 'google', timestamp: Date.now() };
  }
  
  configure(config: AIInfererConfig): void {
    this.config = { ...this.config, ...config };
  }
  
  getConfig(): AIInfererConfig { return { ...this.config }; }
}
