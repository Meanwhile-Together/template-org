/**
 * @fileoverview Server AI router - Resolves AI providers and exposes getInferrer for the AI addon. Config injected by caller.
 */

import { createAIInferer } from './ai-inferer';
import { ProviderResolver } from '@meanwhile-together/shared/utils/provider-resolver-standalone';
import type { AIInfererImpl, AIProvider } from '@meanwhile-together/shared';
import { AIProviderType, PROVIDER_MAPPINGS } from '@meanwhile-together/shared/ai-constants';
import type { AIAddonRouter } from '@meanwhile-together/shared/addons';
import type { ServerAIMode, UnifiedConfig } from '@meanwhile-together/shared';

/**
 * Config slice for the server AI router (mode, ai, providers). Caller passes getConfig() from server.
 * @typedef {Pick<UnifiedConfig, 'mode'|'ai'|'providers'>} ServerAIRouterConfig
 */
export type ServerAIRouterConfig = Pick<UnifiedConfig, 'mode' | 'ai' | 'providers'>;

/**
 * Server AI router: HF default + custom providers (Google, etc.); getInferrer(provider?, mode?, model?) returns inferrer.
 */
export class ServerAIRouter implements AIAddonRouter {
  private customInferrers: Map<AIProvider, AIInfererImpl> = new Map();
  private hfInferrer: AIInfererImpl | null = null;

  /**
   * @param {Partial<ServerAIRouterConfig>} [config] - mode, ai.localConfig, providers (name -> { apiKey, ... }).
   */
  constructor(config?: Partial<ServerAIRouterConfig>) {
    const mode = config?.mode ?? 'development';
    const isDev = mode === 'development' || mode === 'staging';

    this.hfInferrer = createAIInferer({
      inferenceMode: 'local',
      enableLogging: isDev,
      localConfig: {
        allowedModels: config?.ai?.localConfig?.allowedModels ?? ['*'],
      },
    });

    if (config?.providers) {
      for (const [name, providerConfig] of Object.entries(config.providers)) {
        if (providerConfig && typeof providerConfig === 'object' && 'apiKey' in providerConfig && providerConfig.apiKey) {
          const mapping = PROVIDER_MAPPINGS.find((m) => m.provider === name);

          if (mapping?.type === AIProviderType.CUSTOM) {
            try {
              const inferrer = createAIInferer({
                provider: { name, ...(providerConfig as { apiKey: string; baseUrl?: string }) },
                enableLogging: isDev,
              });
              this.customInferrers.set(mapping.provider, inferrer);

              if (isDev) {
                console.log(`[ServerAIRouter] Enabled custom provider: ${name}`);
              }
            } catch (error) {
              console.warn(
                `[ServerAIRouter] Failed to initialize ${name}:`,
                error instanceof Error ? error.message : String(error)
              );
            }
          }
        }
      }
    }
  }

  /**
   * Get the appropriate inferrer for provider/model (custom if matched, else HF).
   * @param {string} [provider] - Provider name (e.g. 'google').
   * @param {ServerAIMode} [_mode] - Unused.
   * @param {string} [model] - Model id (used to detect provider when provider not set).
   * @returns {AIInfererImpl}
   * @throws {Error} When no inferrer available.
   */
  getInferrer(provider?: string, _mode?: ServerAIMode, model?: string): AIInfererImpl {
    const detectedProvider = model ? ProviderResolver.detectProvider(model) : null;
    const targetProvider = detectedProvider || provider;

    if (targetProvider) {
      const mapping = PROVIDER_MAPPINGS.find((m) => m.provider === targetProvider);
      if (mapping?.type === AIProviderType.CUSTOM && this.customInferrers.has(mapping.provider)) {
        return this.customInferrers.get(mapping.provider)!;
      }
    }

    if (this.hfInferrer) {
      return this.hfInferrer;
    }

    throw new Error('No AI inference method available');
  }

  /** @returns {string[]} Names of custom providers that were configured. */
  getAvailableProviders(): string[] {
    return Array.from(this.customInferrers.keys());
  }

  /** @returns {ServerAIMode[]} Available modes (cloud if custom, local if HF). */
  getAvailableModes(): ServerAIMode[] {
    const modes: ServerAIMode[] = [];
    if (this.customInferrers.size > 0) modes.push('cloud');
    if (this.hfInferrer) modes.push('local');
    return modes;
  }

  /** @returns {boolean} Whether local (HF) inferrer is enabled. */
  isLocalEnabled(): boolean {
    return this.hfInferrer !== null;
  }

  /** @returns {number} Number of custom providers. */
  getProviderCount(): number {
    return this.customInferrers.size;
  }

  /**
   * Detect provider from model id (e.g. google/gemini-* -> 'google').
   * @param {string} model - Model identifier.
   * @returns {string | null} Provider name or null.
   */
  detectProvider(model: string): string | null {
    return ProviderResolver.detectProvider(model);
  }
}

let cachedRouter: ServerAIRouter | null = null;

/**
 * Get or create singleton server AI router. Pass config from server (e.g. getConfig()).
 * @param {Partial<ServerAIRouterConfig>} [config] - mode, ai, providers.
 * @returns {AIAddonRouter}
 */
export function createAIServerRouter(config?: Partial<ServerAIRouterConfig>): AIAddonRouter {
  if (!cachedRouter) {
    cachedRouter = new ServerAIRouter(config);
  }
  return cachedRouter;
}
