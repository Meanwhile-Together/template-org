import { parseStructuredOutput } from './parse';

describe('parseStructuredOutput', () => {
  it('parses fenced JSON and validates shape', () => {
    const result = parseStructuredOutput(
      '```json\n{"title":"Todo","priority":2}\n```',
      {
        name: 'task',
        validate: (value: unknown): value is { title: string; priority: number } => {
          const row = value as { title?: unknown; priority?: unknown };
          return typeof row?.title === 'string' && typeof row?.priority === 'number';
        },
      }
    );

    expect(result.ok).toBe(true);
    expect(result.data).toEqual({ title: 'Todo', priority: 2 });
  });

  it('returns a validation error for mismatched structure', () => {
    const result = parseStructuredOutput('{"title":"Todo"}', {
      name: 'task',
      validate: (value: unknown): value is { title: string; priority: number } => {
        const row = value as { title?: unknown; priority?: unknown };
        return typeof row?.title === 'string' && typeof row?.priority === 'number';
      },
    });

    expect(result.ok).toBe(false);
    expect(result.error).toContain('does not match schema');
  });
});
