export interface StructuredSchema<T> {
  name?: string;
  validate: (value: unknown) => value is T;
}

export interface StructuredParseResult<T> {
  ok: boolean;
  data?: T;
  rawText: string;
  extractedJson?: string;
  error?: string;
}

function extractJsonCandidate(rawText: string): string {
  const trimmed = rawText.trim();
  if (!trimmed) return '';

  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    return trimmed;
  }

  const fencedJsonMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fencedJsonMatch?.[1]) {
    return fencedJsonMatch[1].trim();
  }

  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    return trimmed.slice(firstBrace, lastBrace + 1);
  }

  const firstBracket = trimmed.indexOf('[');
  const lastBracket = trimmed.lastIndexOf(']');
  if (firstBracket >= 0 && lastBracket > firstBracket) {
    return trimmed.slice(firstBracket, lastBracket + 1);
  }

  return '';
}

export function parseStructuredOutput<T>(
  rawText: string,
  schema: StructuredSchema<T>
): StructuredParseResult<T> {
  const extractedJson = extractJsonCandidate(rawText);
  if (!extractedJson) {
    return {
      ok: false,
      rawText,
      error: `No JSON object/array found for schema "${schema.name ?? 'unnamed'}"`,
    };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(extractedJson);
  } catch (error) {
    return {
      ok: false,
      rawText,
      extractedJson,
      error: error instanceof Error ? error.message : 'Failed to parse JSON',
    };
  }

  if (!schema.validate(parsed)) {
    return {
      ok: false,
      rawText,
      extractedJson,
      error: `JSON does not match schema "${schema.name ?? 'unnamed'}"`,
    };
  }

  return {
    ok: true,
    rawText,
    extractedJson,
    data: parsed,
  };
}
