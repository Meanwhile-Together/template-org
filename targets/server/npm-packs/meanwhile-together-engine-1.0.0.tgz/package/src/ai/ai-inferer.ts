/**
 * @fileoverview AI Inferer - Local/cloud/full inference via HuggingFace or custom providers (e.g. Google). Supports runAgent with session store.
 */
type HfInference = any;
import type { 
  AIInfererImpl,
  AIInfererConfig, 
  AiInferenceCapabilities,
  AIInferenceMode,
  RunAgentOptions,
  RunAgentResult
} from '@meanwhile-together/shared';
import { AIProviderType, PROVIDER_MAPPINGS } from '@meanwhile-together/shared/ai-constants';
import { normalizeAllowedModels } from '@meanwhile-together/shared/utils/normalize-allowed-models';
import { parseSessionKey, SessionStore } from '../session';

/**
 * AI inferer: text generation, chat, classification, etc. Modes: local (HF), cloud (proxy), full (local with server fallback).
 */
export class AIInferer implements AIInfererImpl {
  private client: HfInference | null = null;
  private clientPromise: Promise<HfInference> | null = null;
  private config: AIInfererConfig;

  /**
   * @param {AIInfererConfig} [config={}] - inferenceMode, localConfig, proxyServerUrl, provider, etc.
   */
  constructor(config: AIInfererConfig = {}) {
    // Normalize allowedModels at framework level (handles comma-separated with prefix inheritance)
    const normalizedConfig = { ...config };
    if (normalizedConfig.localConfig?.allowedModels) {
      normalizedConfig.localConfig = {
        ...normalizedConfig.localConfig,
        allowedModels: normalizeAllowedModels(normalizedConfig.localConfig.allowedModels)
      };
    }
    
    this.config = { 
      inferenceMode: 'local', // Local-first by default
      enableLogging: false, 
      ...normalizedConfig 
    };
    
    // Initialize browser storage for local mode
    if (this.config.inferenceMode === 'local' && this.config.localConfig?.usePersistentStorage) {
      this.requestPersistentStorage();
    }
  }
  
  private async getClient(): Promise<HfInference> {
    if (this.client) {
      return this.client;
    }
    
    if (this.clientPromise) {
      return this.clientPromise;
    }
    
    this.clientPromise = this.createClient();
    this.client = await this.clientPromise;
    return this.client;
  }
  
  private async createClient(): Promise<HfInference> {
    // Dynamic import for ESM-only package in CommonJS context
    const { HfInference } = await import('@huggingface/inference');
    const mode = (this.config.inferenceMode || 'local') as AIInferenceMode;
    
    switch (mode) {
      case 'local':
        // Local inference: HF Hub downloads models to browser storage
        const hfToken = this.config.localConfig?.huggingfaceToken;
        return new HfInference(hfToken);
        
      case 'cloud':
        // Cloud mode: always use server via proxyServerUrl
        if (!this.config.proxyServerUrl) {
          throw new Error('Cloud mode requires proxyServerUrl');
        }
        return new HfInference();
        
      case 'full':
        // Full mode: create local client (for try-local-first), server fallback handled in methods
        const fullToken = this.config.localConfig?.huggingfaceToken;
        return new HfInference(fullToken);
        
      default:
        throw new Error(`Unknown inference mode: ${mode}`);
    }
  }

  // Helper method to call server via proxyServerUrl
  private async callServerMethod(method: string, args: any, _options?: any): Promise<any> {
    if (!this.config.proxyServerUrl) {
      throw new Error('proxyServerUrl is required for server fallback');
    }
    
    const url = `${this.config.proxyServerUrl}/api/internal/ai/${method}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(args),
    });
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || `Server request failed: ${response.statusText}`);
    }
    
    return await response.json();
  }

  
  private async requestPersistentStorage(): Promise<void> {
    if (typeof navigator === 'undefined' || !navigator.storage) return;
    
    try {
      const isPersisted = await navigator.storage.persist();
      
      if (isPersisted && this.config.enableLogging) {
        console.log('[AIInferer] Persistent storage granted');
      }
      
      // Request storage quota if specified
      if (this.config.localConfig?.storageQuota) {
        const estimate = await navigator.storage.estimate();
        if (this.config.enableLogging) {
          console.log('[AIInferer] Storage:', {
            usage: Math.round((estimate.usage || 0) / 1024 / 1024),
            quota: Math.round((estimate.quota || 0) / 1024 / 1024),
            requested: this.config.localConfig.storageQuota
          });
        }
      }
    } catch (error) {
        if (this.config.enableLogging) {
        console.warn('[AIInferer] Persistent storage request failed:', error);
      }
    }
  }
  
  // Validate model against allowlist (only for local inference)
  private validateModelForDownload(model: string): boolean {
    // Only validate if we're in local mode and have an allowlist
    if (this.config.inferenceMode !== 'local') return true;
    
    const allowedModels = this.config.localConfig?.allowedModels;
    if (!allowedModels || allowedModels.length === 0) return true;
    
    return allowedModels.some(pattern => {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
      return regex.test(model);
    });
  }
  
  /**
   * Generic method dispatcher that handles all inference mode logic
   * @param methodName - Name of the HfInference method to call
   * @param args - Arguments to pass to the method
   * @param options - Optional options
   * @param validateModel - Whether to validate model against allowlist (default: false)
   */
  private async callInferenceMethod<T>(
    methodName: string,
    args: any,
    options?: any,
    validateModel: boolean = false
  ): Promise<T> {
    const mode = (this.config.inferenceMode || 'local') as AIInferenceMode;
    
    // Model validation (only for methods that need it)
    if (validateModel && args.model && !this.validateModelForDownload(args.model)) {
      throw new Error(`Model ${args.model} not in allowlist for local inference`);
    }
    
    // Cloud mode: always use server
    if (mode === 'cloud') {
      return this.callServerMethod(methodName, args, options);
    }
    
    // Full mode: try local first, fallback to server
    if (mode === 'full') {
      try {
        // Validate model if needed (for full mode local attempt)
        if (validateModel && args.model && !this.validateModelForDownload(args.model)) {
          throw new Error(`Model ${args.model} not in allowlist for local inference`);
        }
        const client = await this.getClient();
        const method = client[methodName] as Function;
        return await method.call(client, args, options) as T;
      } catch (error) {
        // Fallback to server if available
        if (this.config.proxyServerUrl) {
          return this.callServerMethod(methodName, args, options);
        }
        throw error;
      }
    }
    
    // Local mode: use local client
    const client = await this.getClient();
    const method = client[methodName] as Function;
    return await method.call(client, args, options) as T;
  }
  
  // All 18 methods delegate to the generic dispatcher
  async textGeneration(args: any, options?: any) {
    return this.callInferenceMethod('textGeneration', args, options, true);
  }

  async chatCompletion(args: any, options?: any) {
    return this.callInferenceMethod('chatCompletion', args, options, true);
  }

  async textClassification(args: any, options?: any) {
    return this.callInferenceMethod('textClassification', args, options);
  }

  async translation(args: any, options?: any) {
    return this.callInferenceMethod('translation', args, options);
  }

  async summarization(args: any, options?: any) {
    return this.callInferenceMethod('summarization', args, options);
  }

  async questionAnswering(args: any, options?: any) {
    return this.callInferenceMethod('questionAnswering', args, options);
  }

  async fillMask(args: any, options?: any) {
    return this.callInferenceMethod('fillMask', args, options);
  }

  async sentenceSimilarity(args: any, options?: any) {
    return this.callInferenceMethod('sentenceSimilarity', args, options);
  }

  async featureExtraction(args: any, options?: any) {
    return this.callInferenceMethod('featureExtraction', args, options);
  }

  async tokenClassification(args: any, options?: any) {
    return this.callInferenceMethod('tokenClassification', args, options);
  }

  async zeroShotClassification(args: any, options?: any) {
    return this.callInferenceMethod('zeroShotClassification', args, options);
  }

  async textToImage(args: any, options?: any) {
    return this.callInferenceMethod('textToImage', args, options);
  }

  async imageClassification(args: any, options?: any) {
    return this.callInferenceMethod('imageClassification', args, options);
  }

  async imageToText(args: any, options?: any) {
    return this.callInferenceMethod('imageToText', args, options);
  }

  async automaticSpeechRecognition(args: any, options?: any) {
    return this.callInferenceMethod('automaticSpeechRecognition', args, options);
  }

  async textToSpeech(args: any, options?: any) {
    return this.callInferenceMethod('textToSpeech', args, options);
  }

  async chatCompletionStream(args: any, options?: any) {
    return this.callInferenceMethod('chatCompletionStream', args, options, true);
  }

  async textGenerationStream(args: any, options?: any) {
    return this.callInferenceMethod('textGenerationStream', args, options, true);
  }

  async runAgent(opts: RunAgentOptions): Promise<RunAgentResult> {
    const parsed = parseSessionKey(opts.sessionKey);
    if (!parsed) {
      throw new Error(`Invalid session key: ${opts.sessionKey}`);
    }
    const store = new SessionStore({ stateDir: opts.stateDir });
    let state = store.get(opts.sessionKey);
    if (!state) {
      state = {
        sessionId: opts.sessionKey,
        updatedAt: Date.now(),
        history: [],
      };
      store.set(opts.sessionKey, state);
    }
    store.markJoin(opts.sessionKey);
    store.markHeartbeat(opts.sessionKey);
    const historyLimit = opts.historyLimit ?? 20;
    const history = (state.history ?? []).slice(-historyLimit);
    const messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }> = [
      ...history,
      { role: 'user', content: opts.prompt },
    ];
    const model = opts.model ?? state.modelOverride ?? 'gemini-2.0-flash';
    if (opts.stream) {
      const stream = await this.chatCompletionStream({ model, messages });
      const payloads: RunAgentResult['payloads'] = [];
      const meta: RunAgentResult['meta'] = { model };
      if (typeof stream === 'object' && stream != null && Symbol.asyncIterator in stream) {
        for await (const chunk of stream as AsyncIterable<{ choices?: Array<{ delta?: { content?: string } }> }>) {
          const text = chunk?.choices?.[0]?.delta?.content;
          if (text) payloads.push({ type: 'text', content: text });
        }
      }
      const fullText = payloads.map((p) => p.content).join('');
      const newHistory: Array<{ role: 'user' | 'assistant' | 'system'; content: string }> = [...(state.history ?? []), { role: 'user', content: opts.prompt }, { role: 'assistant', content: fullText }];
      state.history = newHistory.slice(-historyLimit);
      state.updatedAt = Date.now();
      store.set(opts.sessionKey, state);
      store.markHeartbeat(opts.sessionKey);
      return { payloads, meta };
    }
    const result = await this.chatCompletion({ model, messages }) as { choices?: Array<{ message?: { content?: string } }>; usage?: unknown };
    const content = result?.choices?.[0]?.message?.content ?? '';
    const newHistory: Array<{ role: 'user' | 'assistant' | 'system'; content: string }> = [...(state.history ?? []), { role: 'user', content: opts.prompt }, { role: 'assistant', content }];
    state.history = newHistory.slice(-historyLimit);
    state.updatedAt = Date.now();
    store.set(opts.sessionKey, state);
    store.markHeartbeat(opts.sessionKey);
    return {
      payloads: [{ type: 'text', content }],
      meta: { model, usage: result?.usage },
    };
  }
  
  // Support methods
  async getCapabilities(): Promise<AiInferenceCapabilities> {
    const mode = (this.config.inferenceMode || 'local') as AIInferenceMode;
    return {
      local: mode === 'local' || mode === 'full',
      cloud: mode === 'cloud' || mode === 'full'
    };
  }

  async isAvailable(): Promise<boolean> {
    return true;
  }

  async healthCheck(): Promise<any> {
    return {
      status: 'healthy',
      mode: this.config.inferenceMode,
      timestamp: Date.now()
    };
  }

  configure(config: AIInfererConfig): void {
    this.config = { ...this.config, ...config };
    // Reset client - will be lazily reinitialized on next use
    this.client = null;
    this.clientPromise = null;
  }

  getConfig(): AIInfererConfig {
    return { ...this.config };
  }
}

/**
 * Create an AI inferer (standard AIInferer or custom provider e.g. Google when server-side and config.provider set).
 * @param {AIInfererConfig} [config={}] - Inference config; provider used server-side for custom backends.
 * @returns {AIInfererImpl}
 * @throws {Error} For unsupported custom provider names.
 */
export function createAIInferer(config: AIInfererConfig = {}): AIInfererImpl {
  // Check if this is a custom provider that needs its own implementation
  // Note: Custom providers are typically used server-side with cloud mode
  // For client-side, we use the standard AIInferer which handles cloud via proxyServerUrl
  if (config.provider && typeof window === 'undefined') {
    // Server-side: custom providers can be used directly
    const mapping = PROVIDER_MAPPINGS.find((m: any) => m.provider === config.provider!.name);
    
    if (mapping?.type === AIProviderType.CUSTOM) {
      switch (config.provider!.name) {
        case 'google':
          const { GoogleInferer } = require('./providers/google-inferer.js');
          return new GoogleInferer(config);
        case 'openai':
          throw new Error('OpenAI inferrer not yet implemented');
        case 'anthropic':
          throw new Error('Anthropic inferrer not yet implemented');
      }
    }
  }
  
  // Default to standard AIInferer for all modes (local, full, cloud)
  return new AIInferer(config);
}