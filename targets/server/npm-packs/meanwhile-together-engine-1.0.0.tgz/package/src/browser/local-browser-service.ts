/**
 * @fileoverview Local Browser Service - Direct Playwright execution for Node/Desktop. Can fall back to proxy via useServer(true).
 */

import type {
  BrowserService,
  BrowserConfig,
  BrowserInteractionEvent,
  LoginSelectors,
  BrowserServiceConfig
} from '@meanwhile-together/shared';

// BrowserAutomation class - must be provided via setBrowserAutomationClass()
// This avoids circular dependencies (engine cannot import from application)
let BrowserAutomationClass: any = null;

/**
 * Set the BrowserAutomation class for local browser execution. Call from server/desktop entry before using LocalBrowserService.
 * @param {*} cls - Constructor for BrowserAutomation (e.g. from targets/backend-server).
 */
export function setBrowserAutomationClass(cls: any): void {
  BrowserAutomationClass = cls;
}

async function loadBrowserAutomation(): Promise<any> {
  if (!BrowserAutomationClass) {
    throw new Error(
      'BrowserAutomation class not configured. ' +
      'Call setBrowserAutomationClass() from your server/desktop entry point before using LocalBrowserService.'
    );
  }
  return BrowserAutomationClass;
}

/**
 * Local browser service: wraps BrowserAutomation for direct Playwright; can delegate to proxy when useServer(true).
 */
export class LocalBrowserService implements BrowserService {
  private automation: any = null;
  private _config?: BrowserConfig;
  private _useServer = false;
  private _initialized = false;
  private proxyService?: BrowserService;
  private serviceConfig?: BrowserServiceConfig;

  /**
   * @param {BrowserServiceConfig} [serviceConfig] - Default config for automation.
   * @param {BrowserService} [proxyService] - Optional proxy for useServer(true) fallback.
   */
  constructor(serviceConfig?: BrowserServiceConfig, proxyService?: BrowserService) {
    this.serviceConfig = serviceConfig;
    this.proxyService = proxyService;
  }

  // === Configuration ===

  /**
   * Switch to proxy server for browser operations when enabled.
   * @param {boolean} enabled - Use server (proxy) when true.
   */
  useServer(enabled: boolean): void {
    if (enabled && !this.proxyService) {
      console.warn('[LocalBrowserService] useServer(true) called but no proxy service configured');
    }
    this._useServer = enabled;
  }

  /** @returns {boolean} Always true for LocalBrowserService. */
  canRunLocally(): boolean {
    return true;
  }

  /** @returns {boolean} Whether local or proxy is initialized. */
  isInitialized(): boolean {
    if (this._useServer && this.proxyService) {
      return this.proxyService.isInitialized();
    }
    return this._initialized;
  }

  /** @returns {BrowserConfig | undefined} Current config. */
  getConfig(): BrowserConfig | undefined {
    if (this._useServer && this.proxyService) {
      return this.proxyService.getConfig();
    }
    return this._config;
  }

  /**
   * Set the proxy service for server fallback (useServer(true)).
   * @param {BrowserService} proxy - Proxy browser service.
   */
  setProxyService(proxy: BrowserService): void {
    this.proxyService = proxy;
  }

  // === Lifecycle ===

  /**
   * Initialize local automation or delegate to proxy.
   * @param {BrowserConfig} [config] - Override config for this session.
   * @returns {Promise<void>}
   * @throws When BrowserAutomation not configured or init fails.
   */
  async initialize(config?: BrowserConfig): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.initialize(config);
    }

    if (this._initialized) {
      console.warn('[LocalBrowserService] Already initialized');
      return;
    }

    try {
      const AutomationClass = await loadBrowserAutomation();
      
      const mergedConfig = {
        ...this.serviceConfig?.defaultConfig,
        ...config
      };
      
      this.automation = new AutomationClass(mergedConfig);
      await this.automation.initialize();
      this._config = mergedConfig;
      this._initialized = true;
    } catch (error) {
      console.error('[LocalBrowserService] Initialization failed:', error);
      throw error;
    }
  }

  /** @returns {Promise<void>} */
  async cleanup(): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.cleanup();
    }

    if (this.automation) {
      await this.automation.cleanup();
      this.automation = null;
      this._initialized = false;
    }
  }

  // === Navigation ===

  /**
   * @param {string} url - URL to navigate to.
   * @returns {Promise<void>}
   * @throws When not initialized.
   */
  async navigate(url: string): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.navigate(url);
    }

    this.ensureInitialized();
    await this.automation.navigate(url);
  }

  /** @returns {string} Current page URL or ''. */
  getCurrentUrl(): string {
    if (this._useServer && this.proxyService) {
      return this.proxyService.getCurrentUrl();
    }

    if (!this.automation) {
      return '';
    }
    return this.automation.getCurrentUrl();
  }

  /** @returns {Promise<string>} Current page title. */
  async getCurrentTitle(): Promise<string> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.getCurrentTitle();
    }

    if (!this.automation) {
      return '';
    }
    return this.automation.getCurrentTitle();
  }

  // === Interactions ===

  /**
   * @param {number} x - X coordinate.
   * @param {number} y - Y coordinate.
   * @returns {Promise<void>}
   */
  async click(x: number, y: number): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.click(x, y);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction({ type: 'click', x, y });
  }

  /** @param {string} text - Text to type. @returns {Promise<void>} */
  async type(text: string): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.type(text);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction({ type: 'type', text });
  }

  /** @param {string} key - Key to press. @returns {Promise<void>} */
  async press(key: string): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.press(key);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction({ type: 'key', key });
  }

  /**
   * @param {number} deltaX - Horizontal scroll delta.
   * @param {number} deltaY - Vertical scroll delta.
   * @returns {Promise<void>}
   */
  async scroll(deltaX: number, deltaY: number): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.scroll(deltaX, deltaY);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction({ type: 'scroll', deltaX, deltaY });
  }

  /** @param {number} x - X. @param {number} y - Y. @returns {Promise<void>} */
  async hover(x: number, y: number): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.hover(x, y);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction({ type: 'hover', x, y });
  }

  /**
   * @param {BrowserInteractionEvent} event - Interaction event.
   * @returns {Promise<void>}
   */
  async handleInteraction(event: BrowserInteractionEvent): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.handleInteraction(event);
    }

    this.ensureInitialized();
    await this.automation.handleInteraction(event);
  }

  // === Screenshots ===

  /** @returns {Promise<string>} Base64 or data URL screenshot. */
  async screenshot(): Promise<string> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.screenshot();
    }

    this.ensureInitialized();
    return this.automation.captureScreenshot();
  }

  /**
   * @param {(screenshot: string) => void} callback - Called with each frame.
   * @param {number} [fps=10] - Frames per second.
   */
  startScreenshotStream(callback: (screenshot: string) => void, fps: number = 10): void {
    if (this._useServer && this.proxyService) {
      return this.proxyService.startScreenshotStream(callback, fps);
    }

    this.ensureInitialized();
    const interval = Math.floor(1000 / fps);
    this.automation.startScreenshotStream(callback, interval);
  }

  /** Stop the screenshot stream. */
  stopScreenshotStream(): void {
    if (this._useServer && this.proxyService) {
      return this.proxyService.stopScreenshotStream();
    }

    if (this.automation) {
      this.automation.stopScreenshotStream();
    }
  }

  // === Authentication ===

  /**
   * @param {string} url - Login page URL.
   * @param {LoginSelectors} selectors - Username, password, submit selectors.
   * @returns {Promise<boolean>} Success.
   */
  async performLogin(url: string, selectors: LoginSelectors): Promise<boolean> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.performLogin(url, selectors);
    }

    this.ensureInitialized();
    return this.automation.performLogin(
      url,
      selectors.username,
      selectors.password,
      selectors.submit
    );
  }

  /** @returns {Promise<void>} */
  async saveAuthState(): Promise<void> {
    if (this._useServer && this.proxyService) {
      return this.proxyService.saveAuthState();
    }

    this.ensureInitialized();
    await this.automation.saveAuthState();
  }

  // === Private Helpers ===

  private ensureInitialized(): void {
    if (!this._initialized || !this.automation) {
      throw new Error('Browser not initialized. Call initialize() first.');
    }
  }
}

/**
 * Create a local browser service instance.
 * @param {BrowserServiceConfig} [config] - Service config.
 * @param {BrowserService} [proxyService] - Optional proxy for useServer fallback.
 * @returns {LocalBrowserService}
 */
export function createLocalBrowserService(
  config?: BrowserServiceConfig,
  proxyService?: BrowserService
): LocalBrowserService {
  return new LocalBrowserService(config, proxyService);
}
