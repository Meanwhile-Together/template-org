/**
 * @fileoverview Proxy Browser Service - WebSocket client for server-side Playwright. Used by Web/Mobile or Desktop when useServer(true).
 */

import type {
  BrowserService,
  BrowserConfig,
  BrowserInteractionEvent,
  LoginSelectors,
  BrowserServiceConfig,
  BrowserWebSocketMessage
} from '@meanwhile-together/shared';

/**
 * Proxy browser service: sends commands via WebSocket to server; receives screenshots and status.
 */
export class ProxyBrowserService implements BrowserService {
  private ws: WebSocket | null = null;
  private serverUrl: string;
  private wsPath: string;
  private _config?: BrowserConfig;
  private _initialized = false;
  private _currentUrl = '';
  private _currentTitle = '';
  private screenshotCallback?: (screenshot: string) => void;
  private pendingRequests: Map<string, { resolve: Function; reject: Function }> = new Map();
  private requestIdCounter = 0;

  /**
   * @param {BrowserServiceConfig} [config] - serverUrl, wsPath, defaultConfig.
   */
  constructor(config?: BrowserServiceConfig) {
    // Default to current origin for web, or localhost for other environments
    const defaultUrl = typeof window !== 'undefined' 
      ? `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}`
      : 'ws://localhost:3001';
    
    this.serverUrl = config?.serverUrl || defaultUrl;
    this.wsPath = config?.wsPath || '/ws/browser-automation';
    this._config = config?.defaultConfig;
  }

  // === Configuration ===

  useServer(_enabled: boolean): void {
    // No-op - proxy service always uses server
  }

  canRunLocally(): boolean {
    return false;
  }

  isInitialized(): boolean {
    return this._initialized && this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  getConfig(): BrowserConfig | undefined {
    return this._config;
  }

  // === Lifecycle ===

  async initialize(config?: BrowserConfig): Promise<void> {
    if (this._initialized && this.ws?.readyState === WebSocket.OPEN) {
      console.warn('[ProxyBrowserService] Already initialized');
      return;
    }

    const mergedConfig = { ...this._config, ...config };
    this._config = mergedConfig;

    return new Promise((resolve, reject) => {
      try {
        const wsUrl = `${this.serverUrl}${this.wsPath}`;
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          console.log('[ProxyBrowserService] Connected to server');
          this._initialized = true;
          
          // Send initialize command to server
          this.send({
            type: 'initialize',
            config: mergedConfig
          });
          
          resolve();
        };

        this.ws.onmessage = (event) => {
          this.handleMessage(event.data);
        };

        this.ws.onerror = (error) => {
          console.error('[ProxyBrowserService] WebSocket error:', error);
          reject(new Error('WebSocket connection failed'));
        };

        this.ws.onclose = () => {
          console.log('[ProxyBrowserService] Disconnected from server');
          this._initialized = false;
          this.ws = null;
        };

        // Timeout for connection
        setTimeout(() => {
          if (!this._initialized) {
            reject(new Error('WebSocket connection timeout'));
          }
        }, 10000);
      } catch (error) {
        reject(error);
      }
    });
  }

  async cleanup(): Promise<void> {
    if (this.ws) {
      this.send({ type: 'cleanup' });
      
      // Give server time to process cleanup
      await new Promise(resolve => setTimeout(resolve, 100));
      
      this.ws.close();
      this.ws = null;
      this._initialized = false;
    }
  }

  // === Navigation ===

  async navigate(url: string): Promise<void> {
    this.ensureConnected();
    
    return new Promise((resolve, reject) => {
      const requestId = this.generateRequestId();
      this.pendingRequests.set(requestId, { resolve, reject });
      
      this.send({
        type: 'navigate',
        url,
        data: { requestId }
      });
      
      // Timeout for navigation
      setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          resolve(); // Resolve anyway, navigation might succeed
        }
      }, 30000);
    });
  }

  getCurrentUrl(): string {
    return this._currentUrl;
  }

  async getCurrentTitle(): Promise<string> {
    return this._currentTitle;
  }

  // === Interactions ===

  async click(x: number, y: number): Promise<void> {
    return this.sendInteraction({ type: 'click', x, y });
  }

  async type(text: string): Promise<void> {
    return this.sendInteraction({ type: 'type', text });
  }

  async press(key: string): Promise<void> {
    return this.sendInteraction({ type: 'key', key });
  }

  async scroll(deltaX: number, deltaY: number): Promise<void> {
    return this.sendInteraction({ type: 'scroll', deltaX, deltaY });
  }

  async hover(x: number, y: number): Promise<void> {
    return this.sendInteraction({ type: 'hover', x, y });
  }

  async handleInteraction(event: BrowserInteractionEvent): Promise<void> {
    return this.sendInteraction(event);
  }

  private async sendInteraction(event: BrowserInteractionEvent): Promise<void> {
    this.ensureConnected();
    
    return new Promise((resolve, reject) => {
      const requestId = this.generateRequestId();
      this.pendingRequests.set(requestId, { resolve, reject });
      
      this.send({
        type: 'interaction',
        event,
        data: { requestId }
      });
      
      // Timeout for interaction
      setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          resolve(); // Resolve anyway
        }
      }, 5000);
    });
  }

  // === Screenshots ===

  async screenshot(): Promise<string> {
    this.ensureConnected();
    
    return new Promise((resolve, reject) => {
      const requestId = this.generateRequestId();
      this.pendingRequests.set(requestId, { resolve, reject });
      
      this.send({
        type: 'screenshot',
        data: { requestId }
      });
      
      // Timeout for screenshot
      setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          reject(new Error('Screenshot timeout'));
        }
      }, 10000);
    });
  }

  startScreenshotStream(callback: (screenshot: string) => void, _fps: number = 10): void {
    this.screenshotCallback = callback;
    // Server handles the streaming, we just need to store the callback
  }

  stopScreenshotStream(): void {
    this.screenshotCallback = undefined;
  }

  // === Authentication ===

  async performLogin(url: string, selectors: LoginSelectors): Promise<boolean> {
    this.ensureConnected();
    
    return new Promise((resolve, reject) => {
      const requestId = this.generateRequestId();
      this.pendingRequests.set(requestId, { resolve, reject });
      
      this.send({
        type: 'auth',
        data: {
          requestId,
          loginUrl: url,
          selectors
        }
      });
      
      // Timeout for login
      setTimeout(() => {
        if (this.pendingRequests.has(requestId)) {
          this.pendingRequests.delete(requestId);
          resolve(false);
        }
      }, 60000);
    });
  }

  async saveAuthState(): Promise<void> {
    // Server handles auth state automatically
  }

  // === Private Helpers ===

  private ensureConnected(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error('Not connected to server. Call initialize() first.');
    }
  }

  private send(message: BrowserWebSocketMessage): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  private generateRequestId(): string {
    return `req_${++this.requestIdCounter}_${Date.now()}`;
  }

  private handleMessage(data: string): void {
    try {
      const message: BrowserWebSocketMessage = JSON.parse(data);
      
      switch (message.type) {
        case 'screenshot':
          if (message.screenshot) {
            // Check if this is a response to a specific request
            const requestId = message.data?.requestId;
            if (requestId && this.pendingRequests.has(requestId)) {
              const { resolve } = this.pendingRequests.get(requestId)!;
              this.pendingRequests.delete(requestId);
              resolve(message.screenshot);
            }
            
            // Also call streaming callback if set
            if (this.screenshotCallback) {
              this.screenshotCallback(message.screenshot);
            }
          }
          break;
        
        case 'status':
          // Handle status updates
          const requestId = message.data?.requestId;
          if (requestId && this.pendingRequests.has(requestId)) {
            const { resolve } = this.pendingRequests.get(requestId)!;
            this.pendingRequests.delete(requestId);
            
            // For auth, resolve with success/failure
            if (message.message?.includes('Authentication successful')) {
              resolve(true);
            } else if (message.message?.includes('Authentication failed')) {
              resolve(false);
            } else {
              resolve();
            }
          }
          
          // Update URL if included
          if (message.data?.url) {
            this._currentUrl = message.data.url;
          }
          if (message.data?.title) {
            this._currentTitle = message.data.title;
          }
          break;
        
        case 'error':
          console.error('[ProxyBrowserService] Server error:', message.message);
          const errorRequestId = message.data?.requestId;
          if (errorRequestId && this.pendingRequests.has(errorRequestId)) {
            const { reject } = this.pendingRequests.get(errorRequestId)!;
            this.pendingRequests.delete(errorRequestId);
            reject(new Error(message.message || 'Server error'));
          }
          break;
      }
    } catch (error) {
      console.error('[ProxyBrowserService] Error parsing message:', error);
    }
  }
}

/**
 * Create a proxy browser service instance.
 * @param {BrowserServiceConfig} [config] - Optional config (serverUrl, wsPath, defaultConfig).
 * @returns {ProxyBrowserService}
 */
export function createProxyBrowserService(config?: BrowserServiceConfig): ProxyBrowserService {
  return new ProxyBrowserService(config);
}
