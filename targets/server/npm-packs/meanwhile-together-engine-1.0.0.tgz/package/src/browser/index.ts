/**
 * @fileoverview Browser module - Local, proxy, and stub browser services for Playwright-based automation.
 */

export * from './local-browser-service';
export * from './proxy-browser-service';
export * from './stub-browser-service';
