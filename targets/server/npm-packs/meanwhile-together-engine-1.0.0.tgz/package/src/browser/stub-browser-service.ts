/**
 * @fileoverview Stub Browser Service - Placeholder when browser service is not configured. All ops throw clear errors.
 */

import type {
  BrowserService,
  BrowserConfig,
  BrowserInteractionEvent,
  LoginSelectors
} from '@meanwhile-together/shared';

const NOT_CONFIGURED_ERROR = 'Browser service not configured. Initialize with a platform-specific implementation.';

/**
 * Stub browser service: throws on all operations except no-op cleanup/getCurrentUrl/getCurrentTitle.
 */
export class StubBrowserService implements BrowserService {
  /** No-op. */
  useServer(_enabled: boolean): void {
    // No-op for stub
  }

  canRunLocally(): boolean {
    return false;
  }

  isInitialized(): boolean {
    return false;
  }

  getConfig(): BrowserConfig | undefined {
    return undefined;
  }

  // === Lifecycle ===

  async initialize(_config?: BrowserConfig): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async cleanup(): Promise<void> {
    // No-op for stub - nothing to clean up
  }

  // === Navigation ===

  async navigate(_url: string): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  getCurrentUrl(): string {
    return '';
  }

  async getCurrentTitle(): Promise<string> {
    return '';
  }

  // === Interactions ===

  async click(_x: number, _y: number): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async type(_text: string): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async press(_key: string): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async scroll(_deltaX: number, _deltaY: number): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async hover(_x: number, _y: number): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async handleInteraction(_event: BrowserInteractionEvent): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  // === Screenshots ===

  async screenshot(): Promise<string> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  startScreenshotStream(_callback: (screenshot: string) => void, _fps?: number): void {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  stopScreenshotStream(): void {
    // No-op for stub
  }

  // === Authentication ===

  async performLogin(_url: string, _selectors: LoginSelectors): Promise<boolean> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }

  async saveAuthState(): Promise<void> {
    throw new Error(NOT_CONFIGURED_ERROR);
  }
}

/**
 * Create a stub browser service instance.
 * @returns {StubBrowserService}
 */
export function createStubBrowserService(): StubBrowserService {
  return new StubBrowserService();
}
