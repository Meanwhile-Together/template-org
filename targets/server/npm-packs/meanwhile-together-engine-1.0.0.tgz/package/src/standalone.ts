/**
 * @fileoverview Standalone Engine Framework - Self-contained version for environments without platform bridges.
 * Provides feature detection only; AI text generation is not available (requires a platform bridge).
 */

import { FeatureDetectionService } from '@meanwhile-together/engine';

/**
 * Configuration for StandaloneEngine.
 * @typedef {Object} StandaloneEngineConfig
 * @property {'web'|'desktop'|'mobile'|'node'} [platform] - Target platform (default: 'web').
 * @property {boolean} [enableLogging] - Enable console logging.
 */
export interface StandaloneEngineConfig {
  platform?: 'web' | 'desktop' | 'mobile' | 'node';
  enableLogging?: boolean;
}

/**
 * Standalone engine: feature detection only, no platform bridge or AI.
 */
export class StandaloneEngine {
  private featureDetection: FeatureDetectionService;
  private platform: string;
  private logger: Console | null;

  /**
   * Create a StandaloneEngine instance (no bridge).
   * @param {StandaloneEngineConfig} [config={}] - Configuration.
   */
  constructor(config: StandaloneEngineConfig = {}) {
    this.platform = config.platform || 'web';
    this.logger = config.enableLogging ? console : null;

    // Initialize feature detection
    this.featureDetection = new FeatureDetectionService(
      undefined, // No platform bridge
      this.platform,
      { enableLogging: config.enableLogging }
    );
    
    this.log('StandaloneEngine initialized', { platform: this.platform });
  }

  /**
   * Detect all features (available and unavailable).
   * @returns {any[]} Detected features.
   */
  detectAll(): any[] {
    return this.featureDetection.detectAll();
  }

  /**
   * Detect only enabled/available features.
   * @returns {any[]}
   */
  detectEnabled(): any[] {
    return this.featureDetection.detectEnabled();
  }

  /**
   * Check if a feature is available.
   * @param {string} featureName - Feature identifier.
   * @returns {boolean}
   */
  has(featureName: string): boolean {
    return this.featureDetection.has(featureName);
  }

  /**
   * Get features grouped by category.
   * @returns {Record<string, any[]>}
   */
  byCategory(): Record<string, any[]> {
    return this.featureDetection.byCategory();
  }

  /**
   * Get platform capabilities object.
   * @returns {*} Platform capabilities.
   */
  capabilities(): any {
    return this.featureDetection.capabilities();
  }

  /**
   * Get feature statistics.
   * @returns {*} Stats (total, available, unavailable, byCategory).
   */
  stats(): any {
    return this.featureDetection.stats();
  }

  /**
   * Get platform identifier.
   * @returns {string}
   */
  getPlatform(): string {
    return this.platform;
  }

  /**
   * Get the underlying feature detection service.
   * @returns {FeatureDetectionService}
   */
  getFeatureDetection(): FeatureDetectionService {
    return this.featureDetection;
  }

  /**
   * AI text generation is not available in standalone mode; requires a platform bridge.
   * @param {string} _prompt - Unused.
   * @param {*} [_options] - Unused.
   * @returns {Promise<any>}
   * @throws {Error} Always throws.
   */
  async aiTextGeneration(_prompt: string, _options?: any): Promise<any> {
    throw new Error('AI text generation requires a platform bridge. Use EngineFramework with a platform bridge instead.');
  }

  private log(message: string, data?: any): void {
    if (this.logger) {
      this.logger.log(`[StandaloneEngine] ${message}`, data);
    }
  }
}

let globalStandaloneEngine: StandaloneEngine | null = null;

/**
 * Create or get the global StandaloneEngine instance.
 * @param {StandaloneEngineConfig} [config] - Config used only on first creation.
 * @returns {StandaloneEngine}
 */
export function createStandaloneEngine(config?: StandaloneEngineConfig): StandaloneEngine {
  if (!globalStandaloneEngine) {
    globalStandaloneEngine = new StandaloneEngine(config);
  }
  return globalStandaloneEngine;
}

/**
 * Get the global StandaloneEngine instance, if any.
 * @returns {StandaloneEngine | null}
 */
export function getStandaloneEngine(): StandaloneEngine | null {
  return globalStandaloneEngine;
}

/**
 * Reset the global StandaloneEngine instance (useful for testing).
 */
export function resetStandaloneEngine(): void {
  globalStandaloneEngine = null;
}
