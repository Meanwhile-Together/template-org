# Project Bridge demo

This package is the **Project Bridge demo** — the default payload shown when routing is not set up, or no routed application has an app to render, or the default route has no app configured.

It is consumed by the client, desktop, and mobile targets.

**Expected surface (so targets keep working):**

- **Default export / `App`** — Root React component (splash → demo → technical). Used by targets/client, targets/desktop, targets/mobile.
- **`/views`** — `getAppViews()`, `getViewComponent(id)` (used by shared views provider and server payload enrichment).
- **`/api`** — `getAppRoutes()` (used by shared router provider and server payload enrichment).

Build: `npm run build` (or from root: `npm run build:demo`).
